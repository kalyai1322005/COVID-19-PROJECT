import React from 'react';
import { FileText, Download, BarChart3, TrendingUp, AlertCircle, CheckCircle, XCircle, Activity } from 'lucide-react';
import { keyInsights, dailyData, stateData, vaccinationData } from '../data/covidData';

const Insights = () => {
  const generateReport = () => {
    const reportContent = `
COVID-19 INDIA ANALYSIS REPORT (2020-2022)
=========================================

EXECUTIVE SUMMARY
This comprehensive analysis examines India's COVID-19 pandemic response and impact from March 2020 to December 2022. The study reveals three distinct waves, successful vaccination campaigns, and significant regional variations in disease burden.

KEY FINDINGS
- Total Cases: ${dailyData[dailyData.length - 1].cases.toLocaleString()}
- Total Deaths: ${dailyData[dailyData.length - 1].deaths.toLocaleString()}
- Recovery Rate: ${(((dailyData[dailyData.length - 1].recovered / dailyData[dailyData.length - 1].cases) * 100)).toFixed(1)}%
- Vaccination Coverage: Over 2.2 billion doses administered

WAVE ANALYSIS
1. First Wave (March-December 2020): Peak of 97,894 daily cases
2. Second Wave (March-July 2021): Peak of 414,188 daily cases - most severe
3. Third Wave (December 2021-March 2022): Peak of 347,254 daily cases - Omicron variant

RECOMMENDATIONS
1. Strengthen healthcare infrastructure for future pandemics
2. Maintain vaccination programs and booster campaigns
3. Improve rural healthcare access and data collection
4. Enhance surveillance systems for early detection
5. Build strategic medical supply reserves
    `;
    
    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'COVID19_India_Analysis_Report_2020-2022.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const InsightCard = ({ insight, index }: { insight: typeof keyInsights[0], index: number }) => {
    const getImpactColor = (impact: string) => {
      switch (impact) {
        case 'High':
          return 'bg-red-100 text-red-800 border-red-200';
        case 'Medium':
          return 'bg-yellow-100 text-yellow-800 border-yellow-200';
        case 'Low':
          return 'bg-green-100 text-green-800 border-green-200';
        default:
          return 'bg-gray-100 text-gray-800 border-gray-200';
      }
    };

    const getImpactIcon = (impact: string) => {
      switch (impact) {
        case 'High':
          return <AlertCircle className="h-4 w-4" />;
        case 'Medium':
          return <Activity className="h-4 w-4" />;
        case 'Low':
          return <CheckCircle className="h-4 w-4" />;
        default:
          return <XCircle className="h-4 w-4" />;
      }
    };

    return (
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
              <span className="text-indigo-600 font-semibold text-sm">{index + 1}</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-900">{insight.title}</h3>
          </div>
          <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getImpactColor(insight.impact)}`}>
            {getImpactIcon(insight.impact)}
            <span className="ml-1">{insight.impact} Impact</span>
          </div>
        </div>
        <p className="text-gray-600 leading-relaxed">{insight.description}</p>
      </div>
    );
  };

  const StatisticalSummary = () => {
    const latestData = dailyData[dailyData.length - 1];
    const totalPopulation = stateData.reduce((sum, state) => sum + state.population, 0);
    const latestVaccination = vaccinationData[vaccinationData.length - 1];
    
    return (
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-2xl font-semibold text-gray-900 mb-6">Statistical Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">
              {((latestData.cases / totalPopulation) * 100).toFixed(1)}%
            </div>
            <p className="text-sm text-gray-600">Population Infected</p>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-red-600 mb-2">
              {((latestData.deaths / latestData.cases) * 100).toFixed(2)}%
            </div>
            <p className="text-sm text-gray-600">Case Fatality Rate</p>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">
              {((latestData.recovered / latestData.cases) * 100).toFixed(1)}%
            </div>
            <p className="text-sm text-gray-600">Recovery Rate</p>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">
              {((latestVaccination.firstDose / totalPopulation) * 100).toFixed(0)}%
            </div>
            <p className="text-sm text-gray-600">Vaccination Coverage</p>
          </div>
        </div>
      </div>
    );
  };

  const ResearchMethodology = () => (
    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
      <h3 className="text-2xl font-semibold text-gray-900 mb-6">Research Methodology</h3>
      <div className="space-y-4">
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
            <span className="text-blue-600 text-xs font-bold">1</span>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Data Collection</h4>
            <p className="text-gray-600 text-sm">Aggregated data from Ministry of Health & Family Welfare, WHO, and state health departments covering March 2020 to December 2022.</p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
            <span className="text-green-600 text-xs font-bold">2</span>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Data Cleaning & Validation</h4>
            <p className="text-gray-600 text-sm">Standardized reporting formats, handled missing data, and cross-validated with multiple sources for accuracy.</p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
            <span className="text-purple-600 text-xs font-bold">3</span>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Statistical Analysis</h4>
            <p className="text-gray-600 text-sm">Applied time series analysis, trend identification, wave pattern recognition, and population-adjusted metrics calculation.</p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
            <span className="text-orange-600 text-xs font-bold">4</span>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Visualization & Reporting</h4>
            <p className="text-gray-600 text-sm">Created interactive dashboards, comparative charts, and comprehensive reports for stakeholder communication.</p>
          </div>
        </div>
      </div>
    </div>
  );

  const RecommendationsSection = () => (
    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
      <h3 className="text-2xl font-semibold text-gray-900 mb-6">Key Recommendations</h3>
      <div className="space-y-4">
        {[
          {
            title: "Healthcare Infrastructure",
            description: "Strengthen hospital capacity, ICU beds, and oxygen supply chains based on lessons from the second wave.",
            priority: "High"
          },
          {
            title: "Vaccination Strategy",
            description: "Maintain high vaccination coverage and implement targeted booster campaigns for vulnerable populations.",
            priority: "High"
          },
          {
            title: "Rural Health Access",
            description: "Improve healthcare delivery and vaccination access in rural areas where coverage remains lower.",
            priority: "Medium"
          },
          {
            title: "Surveillance Systems",
            description: "Enhance early warning systems and genomic surveillance for rapid variant detection and response.",
            priority: "High"
          },
          {
            title: "Data Management",
            description: "Standardize data collection and reporting across states for better real-time decision making.",
            priority: "Medium"
          }
        ].map((rec, index) => (
          <div key={index} className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
            <div className={`px-2 py-1 rounded text-xs font-medium ${
              rec.priority === 'High' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
            }`}>
              {rec.priority}
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-gray-900 mb-1">{rec.title}</h4>
              <p className="text-gray-600 text-sm">{rec.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Insights & Analysis Report</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Comprehensive analysis of India's COVID-19 pandemic journey, key insights, 
          lessons learned, and recommendations for future pandemic preparedness.
        </p>
      </div>

      {/* Report Actions */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-3">
            <FileText className="h-6 w-6 text-indigo-600" />
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Analysis Report</h3>
              <p className="text-sm text-gray-600">Complete findings and recommendations</p>
            </div>
          </div>
          <button
            onClick={generateReport}
            className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200"
          >
            <Download className="h-4 w-4" />
            <span>Download Report</span>
          </button>
        </div>
      </div>

      {/* Statistical Summary */}
      <StatisticalSummary />

      {/* Key Insights */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Key Insights</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {keyInsights.map((insight, index) => (
            <InsightCard key={index} insight={insight} index={index} />
          ))}
        </div>
      </div>

      {/* Research Methodology */}
      <ResearchMethodology />

      {/* Recommendations */}
      <RecommendationsSection />

      {/* Data Sources */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-2xl font-semibold text-gray-900 mb-6">Data Sources & References</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-semibold text-gray-900 mb-3">Primary Sources</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>• Ministry of Health & Family Welfare, Government of India</li>
              <li>• Indian Council of Medical Research (ICMR)</li>
              <li>• World Health Organization (WHO)</li>
              <li>• State Health Department Reports</li>
              <li>• CoWIN Vaccination Platform Data</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900 mb-3">Analysis Period</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>• Start Date: March 15, 2020 (First case reported)</li>
              <li>• End Date: December 31, 2022</li>
              <li>• Total Duration: 1,022 days</li>
              <li>• Data Points: Daily case, death, recovery, vaccination data</li>
              <li>• Geographic Coverage: All 28 states and 8 union territories</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Footer Note */}
      <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-6">
        <div className="flex items-start space-x-3">
          <BarChart3 className="h-6 w-6 text-indigo-600 flex-shrink-0 mt-1" />
          <div>
            <h4 className="font-semibold text-indigo-900 mb-2">Research Impact</h4>
            <p className="text-indigo-800 text-sm leading-relaxed">
              This comprehensive analysis provides valuable insights for public health policy, 
              pandemic preparedness, and healthcare system strengthening. The findings contribute 
              to India's evidence-based approach for future health emergency responses and support 
              data-driven decision making at national and state levels.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Insights;