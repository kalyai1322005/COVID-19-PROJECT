import React, { useState } from 'react';
import { BarChart3, LineChart, PieChart, Calendar } from 'lucide-react';
import { dailyData, stateData, vaccinationData } from '../data/covidData';

const DataVisualization = () => {
  const [activeChart, setActiveChart] = useState('daily-trends');
  const [selectedPeriod, setSelectedPeriod] = useState('all');

  const filterDataByPeriod = (data: any[]) => {
    if (selectedPeriod === 'all') return data;
    
    const currentDate = new Date();
    const filterDate = new Date();
    
    switch (selectedPeriod) {
      case '2020':
        return data.filter(d => d.date.startsWith('2020'));
      case '2021':
        return data.filter(d => d.date.startsWith('2021'));
      case '2022':
        return data.filter(d => d.date.startsWith('2022'));
      default:
        return data;
    }
  };

  const DailyTrendsChart = () => {
    const filteredData = filterDataByPeriod(dailyData);
    const maxCases = Math.max(...filteredData.map(d => d.cases));
    
    return (
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Daily Cases Trend</h3>
        <div className="h-96 flex items-end space-x-1 overflow-x-auto">
          {filteredData.map((data, index) => {
            const height = (data.cases / maxCases) * 100;
            const date = new Date(data.date);
            const monthYear = date.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' });
            
            return (
              <div key={index} className="flex flex-col items-center min-w-0 flex-1">
                <div className="relative group">
                  <div
                    className="bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-sm hover:from-blue-700 hover:to-blue-500 transition-colors duration-200 cursor-pointer"
                    style={{ height: `${height}%`, minHeight: '2px', width: '100%' }}
                  />
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-gray-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">
                    <div>{data.cases.toLocaleString()} cases</div>
                    <div>{date.toLocaleDateString('en-IN')}</div>
                  </div>
                </div>
                <div className="text-xs text-gray-600 mt-2 transform -rotate-45 origin-left">
                  {monthYear}
                </div>
              </div>
            );
          })}
        </div>
        <div className="mt-4 flex justify-between text-sm text-gray-600">
          <span>Mar 2020</span>
          <span>Dec 2022</span>
        </div>
      </div>
    );
  };

  const StateComparisonChart = () => {
    const topStates = stateData.slice(0, 10);
    const maxCases = Math.max(...topStates.map(s => s.cases));
    
    return (
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">State-wise Cases Comparison</h3>
        <div className="space-y-4">
          {topStates.map((state, index) => {
            const percentage = (state.cases / maxCases) * 100;
            const casesPerLakh = ((state.cases / state.population) * 100000).toFixed(0);
            
            return (
              <div key={state.state} className="flex items-center space-x-4">
                <div className="w-32 text-sm font-medium text-gray-700 truncate">
                  {state.state}
                </div>
                <div className="flex-1 bg-gray-200 rounded-full h-6 relative">
                  <div
                    className="bg-gradient-to-r from-indigo-500 to-purple-600 h-6 rounded-full flex items-center justify-end pr-2 transition-all duration-500"
                    style={{ width: `${percentage}%` }}
                  >
                    <span className="text-white text-xs font-medium">
                      {state.cases.toLocaleString()}
                    </span>
                  </div>
                </div>
                <div className="w-20 text-xs text-gray-600 text-right">
                  {casesPerLakh}/100K
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const VaccinationChart = () => {
    const filteredVaccinationData = filterDataByPeriod(vaccinationData);
    const maxDoses = Math.max(...filteredVaccinationData.map(d => 
      d.firstDose + d.secondDose + d.booster
    ));
    
    return (
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Vaccination Progress Over Time</h3>
        <div className="h-96 flex items-end space-x-1">
          {filteredVaccinationData.map((data, index) => {
            const totalHeight = ((data.firstDose + data.secondDose + data.booster) / maxDoses) * 100;
            const firstDoseHeight = (data.firstDose / maxDoses) * 100;
            const secondDoseHeight = (data.secondDose / maxDoses) * 100;
            const boosterHeight = (data.booster / maxDoses) * 100;
            
            const date = new Date(data.date);
            const monthYear = date.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' });
            
            return (
              <div key={index} className="flex flex-col items-center flex-1 min-w-0">
                <div className="relative group w-full">
                  <div className="w-full rounded-t-sm" style={{ height: `${totalHeight}%`, minHeight: '2px' }}>
                    <div className="bg-blue-500 w-full" style={{ height: `${(firstDoseHeight / totalHeight) * 100}%` }} />
                    <div className="bg-green-500 w-full" style={{ height: `${(secondDoseHeight / totalHeight) * 100}%` }} />
                    <div className="bg-purple-500 w-full rounded-t-sm" style={{ height: `${(boosterHeight / totalHeight) * 100}%` }} />
                  </div>
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">
                    <div>First: {data.firstDose.toLocaleString()}</div>
                    <div>Second: {data.secondDose.toLocaleString()}</div>
                    <div>Booster: {data.booster.toLocaleString()}</div>
                    <div className="border-t border-gray-600 mt-1 pt-1">
                      {date.toLocaleDateString('en-IN')}
                    </div>
                  </div>
                </div>
                <div className="text-xs text-gray-600 mt-2 transform -rotate-45 origin-left">
                  {monthYear}
                </div>
              </div>
            );
          })}
        </div>
        <div className="mt-4 flex justify-center space-x-6 text-sm">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-500 rounded mr-2"></div>
            <span>First Dose</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded mr-2"></div>
            <span>Second Dose</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-purple-500 rounded mr-2"></div>
            <span>Booster</span>
          </div>
        </div>
      </div>
    );
  };

  const WaveAnalysisChart = () => {
    const waveData = [
      { wave: 'First Wave', peak: '2020-09-16', cases: 97894, period: 'Mar-Dec 2020' },
      { wave: 'Second Wave', peak: '2021-05-07', cases: 414188, period: 'Mar-Jul 2021' },
      { wave: 'Third Wave', peak: '2022-01-21', cases: 347254, period: 'Dec 2021-Mar 2022' }
    ];
    
    const maxWaveCases = Math.max(...waveData.map(w => w.cases));
    
    return (
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">COVID-19 Waves Analysis</h3>
        <div className="space-y-6">
          {waveData.map((wave, index) => {
            const height = (wave.cases / maxWaveCases) * 200;
            const colors = ['bg-red-500', 'bg-orange-500', 'bg-yellow-500'];
            
            return (
              <div key={index} className="flex items-center space-x-6">
                <div className="w-32">
                  <h4 className="font-semibold text-gray-900">{wave.wave}</h4>
                  <p className="text-sm text-gray-600">{wave.period}</p>
                </div>
                <div className="flex-1">
                  <div className="flex items-end h-12">
                    <div
                      className={`${colors[index]} rounded-t transition-all duration-1000 flex items-end justify-center pb-1`}
                      style={{ height: `${height / 4}px`, width: '100%' }}
                    >
                      <span className="text-white text-xs font-medium">
                        {wave.cases.toLocaleString()}
                      </span>
                    </div>
                  </div>
                  <div className="text-xs text-gray-600 mt-1">
                    Peak: {new Date(wave.peak).toLocaleDateString('en-IN')}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const chartOptions = [
    { id: 'daily-trends', label: 'Daily Cases Trend', icon: LineChart },
    { id: 'state-comparison', label: 'State Comparison', icon: BarChart3 },
    { id: 'vaccination', label: 'Vaccination Progress', icon: PieChart },
    { id: 'wave-analysis', label: 'Wave Analysis', icon: Calendar },
  ];

  const renderChart = () => {
    switch (activeChart) {
      case 'daily-trends':
        return <DailyTrendsChart />;
      case 'state-comparison':
        return <StateComparisonChart />;
      case 'vaccination':
        return <VaccinationChart />;
      case 'wave-analysis':
        return <WaveAnalysisChart />;
      default:
        return <DailyTrendsChart />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Data Visualizations</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Interactive charts and graphs showing COVID-19 trends, patterns, and insights from India's pandemic data.
        </p>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0 bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        {/* Chart Selection */}
        <div className="flex flex-wrap gap-2">
          {chartOptions.map((option) => {
            const Icon = option.icon;
            return (
              <button
                key={option.id}
                onClick={() => setActiveChart(option.id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium text-sm transition-colors duration-200 ${
                  activeChart === option.id
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{option.label}</span>
              </button>
            );
          })}
        </div>

        {/* Period Selection */}
        <div className="flex items-center space-x-2">
          <span className="text-sm font-medium text-gray-700">Period:</span>
          <select
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          >
            <option value="all">All Years</option>
            <option value="2020">2020</option>
            <option value="2021">2021</option>
            <option value="2022">2022</option>
          </select>
        </div>
      </div>

      {/* Chart Display */}
      <div className="transition-all duration-300">
        {renderChart()}
      </div>

      {/* Key Metrics Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl p-6 text-white">
          <h3 className="text-lg font-semibold mb-2">Peak Daily Cases</h3>
          <div className="text-3xl font-bold mb-1">414,188</div>
          <p className="text-blue-100 text-sm">May 7, 2021 (Second Wave)</p>
        </div>
        
        <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-xl p-6 text-white">
          <h3 className="text-lg font-semibold mb-2">Vaccination Milestone</h3>
          <div className="text-3xl font-bold mb-1">2.2B+</div>
          <p className="text-green-100 text-sm">Total doses administered</p>
        </div>
        
        <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl p-6 text-white">
          <h3 className="text-lg font-semibold mb-2">Recovery Rate</h3>
          <div className="text-3xl font-bold mb-1">98.8%</div>
          <p className="text-purple-100 text-sm">Overall recovery rate</p>
        </div>
      </div>
    </div>
  );
};

export default DataVisualization;