import React, { useState } from 'react';
import { Globe, TrendingUp, Users, Skull, Heart, Search, Filter } from 'lucide-react';
import { globalDailyData, countryInfo, globalVaccinationData } from '../data/globalCovidData';

const CountryComparison = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('cases');
  const [sortOrder, setSortOrder] = useState('desc');
  const [selectedMetric, setSelectedMetric] = useState('total');

  const countries = Object.keys(globalDailyData);
  
  const getCountryStats = (country: string) => {
    const data = globalDailyData[country as keyof typeof globalDailyData];
    const latest = data[data.length - 1];
    const info = countryInfo[country as keyof typeof countryInfo];
    const vacData = globalVaccinationData[country as keyof typeof globalVaccinationData];
    const latestVac = vacData ? vacData[vacData.length - 1] : null;
    
    return {
      country,
      name: info.name,
      continent: info.continent,
      population: info.population,
      cases: latest.cases,
      deaths: latest.deaths,
      recovered: latest.recovered,
      active: latest.active,
      recoveryRate: (latest.recovered / latest.cases) * 100,
      mortalityRate: (latest.deaths / latest.cases) * 100,
      casesPerMillion: (latest.cases / info.population) * 1000000,
      deathsPerMillion: (latest.deaths / info.population) * 1000000,
      infectionRate: (latest.cases / info.population) * 100,
      vaccinationRate: latestVac ? (latestVac.firstDose / info.population) * 100 : 0,
      fullyVaccinatedRate: latestVac ? (latestVac.secondDose / info.population) * 100 : 0,
      boosterRate: latestVac ? (latestVac.booster / info.population) * 100 : 0
    };
  };

  const filteredCountries = countries
    .map(getCountryStats)
    .filter(country => 
      country.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      country.continent.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      let aValue, bValue;
      
      switch (sortBy) {
        case 'cases':
          aValue = a.cases;
          bValue = b.cases;
          break;
        case 'deaths':
          aValue = a.deaths;
          bValue = b.deaths;
          break;
        case 'recovery':
          aValue = a.recoveryRate;
          bValue = b.recoveryRate;
          break;
        case 'mortality':
          aValue = a.mortalityRate;
          bValue = b.mortalityRate;
          break;
        case 'casesPerMillion':
          aValue = a.casesPerMillion;
          bValue = b.casesPerMillion;
          break;
        case 'vaccination':
          aValue = a.vaccinationRate;
          bValue = b.vaccinationRate;
          break;
        case 'population':
          aValue = a.population;
          bValue = b.population;
          break;
        default:
          aValue = a.cases;
          bValue = b.cases;
      }
      
      return sortOrder === 'desc' ? bValue - aValue : aValue - bValue;
    });

  const CountryCard = ({ country }: { country: ReturnType<typeof getCountryStats> }) => {
    return (
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-indigo-100 rounded-lg">
              <Globe className="h-5 w-5 text-indigo-600" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-900">{country.name}</h3>
              <p className="text-sm text-gray-600">{country.continent}</p>
            </div>
          </div>
          <div className="text-right text-sm text-gray-500">
            <div>Pop: {(country.population / 1000000).toFixed(1)}M</div>
            <div>Rank: #{filteredCountries.findIndex(c => c.country === country.country) + 1}</div>
          </div>
        </div>
        
        <div className="space-y-4">
          {/* Total Numbers */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-blue-50 rounded-lg p-3">
              <div className="flex items-center space-x-2 mb-1">
                <Users className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-700">Cases</span>
              </div>
              <div className="text-lg font-bold text-blue-900">
                {country.cases.toLocaleString()}
              </div>
              <div className="text-xs text-blue-600">
                {country.casesPerMillion.toFixed(0)} per million
              </div>
            </div>
            
            <div className="bg-red-50 rounded-lg p-3">
              <div className="flex items-center space-x-2 mb-1">
                <Skull className="h-4 w-4 text-red-600" />
                <span className="text-sm font-medium text-red-700">Deaths</span>
              </div>
              <div className="text-lg font-bold text-red-900">
                {country.deaths.toLocaleString()}
              </div>
              <div className="text-xs text-red-600">
                {country.mortalityRate.toFixed(2)}% CFR
              </div>
            </div>
          </div>
          
          {/* Recovery Rate */}
          <div className="bg-green-50 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <Heart className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium text-green-700">Recovery</span>
              </div>
              <span className="text-sm font-bold text-green-900">{country.recoveryRate.toFixed(1)}%</span>
            </div>
            <div className="w-full bg-green-200 rounded-full h-2">
              <div 
                className="bg-green-600 h-2 rounded-full transition-all duration-500" 
                style={{ width: `${country.recoveryRate}%` }}
              ></div>
            </div>
          </div>

          {/* Vaccination Progress */}
          {country.vaccinationRate > 0 && (
            <div className="bg-purple-50 rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-purple-700">Vaccination</span>
                <span className="text-sm font-bold text-purple-900">{country.vaccinationRate.toFixed(0)}%</span>
              </div>
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-purple-600 w-12">1st</span>
                  <div className="flex-1 bg-purple-200 rounded-full h-2">
                    <div 
                      className="bg-purple-500 h-2 rounded-full transition-all duration-500" 
                      style={{ width: `${Math.min(country.vaccinationRate, 100)}%` }}
                    ></div>
                  </div>
                  <span className="text-xs text-purple-600">{country.vaccinationRate.toFixed(0)}%</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-purple-600 w-12">Full</span>
                  <div className="flex-1 bg-purple-200 rounded-full h-2">
                    <div 
                      className="bg-purple-600 h-2 rounded-full transition-all duration-500" 
                      style={{ width: `${Math.min(country.fullyVaccinatedRate, 100)}%` }}
                    ></div>
                  </div>
                  <span className="text-xs text-purple-600">{country.fullyVaccinatedRate.toFixed(0)}%</span>
                </div>
              </div>
            </div>
          )}

          {/* Key Metrics */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-gray-50 rounded p-2">
              <div className="text-gray-600">Infection Rate</div>
              <div className="font-semibold text-gray-900">{country.infectionRate.toFixed(1)}%</div>
            </div>
            <div className="bg-gray-50 rounded p-2">
              <div className="text-gray-600">Deaths/Million</div>
              <div className="font-semibold text-gray-900">{country.deathsPerMillion.toFixed(0)}</div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const ComparisonTable = () => (
    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 overflow-x-auto">
      <h3 className="text-xl font-semibold text-gray-900 mb-4">Detailed Comparison Table</h3>
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-200">
            <th className="text-left py-3 px-2 font-semibold text-gray-700">Country</th>
            <th className="text-right py-3 px-2 font-semibold text-gray-700">Population</th>
            <th className="text-right py-3 px-2 font-semibold text-gray-700">Total Cases</th>
            <th className="text-right py-3 px-2 font-semibold text-gray-700">Deaths</th>
            <th className="text-right py-3 px-2 font-semibold text-gray-700">CFR %</th>
            <th className="text-right py-3 px-2 font-semibold text-gray-700">Cases/1M</th>
            <th className="text-right py-3 px-2 font-semibold text-gray-700">Vaccination %</th>
          </tr>
        </thead>
        <tbody>
          {filteredCountries.map((country, index) => (
            <tr key={country.country} className="border-b border-gray-100 hover:bg-gray-50">
              <td className="py-3 px-2">
                <div className="flex items-center space-x-2">
                  <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-indigo-100 text-indigo-600 text-xs font-medium">
                    {index + 1}
                  </span>
                  <div>
                    <div className="font-medium">{country.name}</div>
                    <div className="text-xs text-gray-500">{country.continent}</div>
                  </div>
                </div>
              </td>
              <td className="text-right py-3 px-2">{(country.population / 1000000).toFixed(1)}M</td>
              <td className="text-right py-3 px-2 font-medium">{country.cases.toLocaleString()}</td>
              <td className="text-right py-3 px-2 text-red-600">{country.deaths.toLocaleString()}</td>
              <td className="text-right py-3 px-2">{country.mortalityRate.toFixed(2)}%</td>
              <td className="text-right py-3 px-2">{country.casesPerMillion.toFixed(0)}</td>
              <td className="text-right py-3 px-2 text-green-600">{country.vaccinationRate.toFixed(0)}%</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const ContinentSummary = () => {
    const continentStats = filteredCountries.reduce((acc, country) => {
      const continent = country.continent;
      if (!acc[continent]) {
        acc[continent] = {
          countries: 0,
          totalCases: 0,
          totalDeaths: 0,
          totalPopulation: 0,
          avgVaccinationRate: 0
        };
      }
      acc[continent].countries += 1;
      acc[continent].totalCases += country.cases;
      acc[continent].totalDeaths += country.deaths;
      acc[continent].totalPopulation += country.population;
      acc[continent].avgVaccinationRate += country.vaccinationRate;
      return acc;
    }, {} as Record<string, any>);

    Object.keys(continentStats).forEach(continent => {
      continentStats[continent].avgVaccinationRate /= continentStats[continent].countries;
    });

    return (
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Continental Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(continentStats).map(([continent, stats]) => (
            <div key={continent} className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg p-4 border border-indigo-100">
              <h4 className="font-semibold text-gray-900 mb-2">{continent}</h4>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Countries:</span>
                  <span className="font-medium">{stats.countries}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Cases:</span>
                  <span className="font-medium">{stats.totalCases.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Deaths:</span>
                  <span className="font-medium text-red-600">{stats.totalDeaths.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Avg Vaccination:</span>
                  <span className="font-medium text-green-600">{stats.avgVaccinationRate.toFixed(0)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">CFR:</span>
                  <span className="font-medium">{((stats.totalDeaths / stats.totalCases) * 100).toFixed(2)}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Country Comparison Analysis</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Detailed comparison of COVID-19 impact across major countries. Compare total numbers, 
          population-adjusted rates, vaccination progress, and recovery statistics.
        </p>
      </div>

      {/* Controls */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search countries or continents..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-full lg:w-64 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>
          
          {/* Sort Options */}
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-gray-700">Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="cases">Total Cases</option>
              <option value="deaths">Deaths</option>
              <option value="recovery">Recovery Rate</option>
              <option value="mortality">Mortality Rate</option>
              <option value="casesPerMillion">Cases per Million</option>
              <option value="vaccination">Vaccination Rate</option>
              <option value="population">Population</option>
            </select>
            
            <button
              onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')}
              className="flex items-center space-x-1 px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors duration-200 text-sm"
            >
              <TrendingUp className={`h-4 w-4 transition-transform duration-200 ${sortOrder === 'asc' ? 'rotate-180' : ''}`} />
              <span>{sortOrder === 'desc' ? 'High to Low' : 'Low to High'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Continental Summary */}
      <ContinentSummary />

      {/* Country Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCountries.map((country) => (
          <CountryCard key={country.country} country={country} />
        ))}
      </div>

      {/* Comparison Table */}
      <ComparisonTable />

      {/* Results Info */}
      {searchTerm && (
        <div className="text-center text-gray-600">
          Showing {filteredCountries.length} of {countries.length} countries
          {searchTerm && ` matching "${searchTerm}"`}
        </div>
      )}
    </div>
  );
};

export default CountryComparison;