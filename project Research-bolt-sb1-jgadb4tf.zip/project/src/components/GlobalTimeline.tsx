import React, { useState } from 'react';
import { Calendar, AlertTriangle, Shield, Zap, Heart, TrendingUp, Globe, Filter } from 'lucide-react';
import { globalTimelineEvents, countryInfo } from '../data/globalCovidData';

const GlobalTimeline = () => {
  const [selectedCountry, setSelectedCountry] = useState('global');
  const [selectedEventType, setSelectedEventType] = useState('all');

  const countries = ['global', ...Object.keys(countryInfo)];
  const eventTypes = ['all', 'milestone', 'policy', 'wave', 'crisis'];

  const filteredEvents = globalTimelineEvents.filter(event => {
    const countryMatch = selectedCountry === 'global' || 
                        event.countries.includes('global') || 
                        event.countries.includes(selectedCountry);
    const typeMatch = selectedEventType === 'all' || event.type === selectedEventType;
    return countryMatch && typeMatch;
  });

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'milestone':
        return <TrendingUp className="h-5 w-5" />;
      case 'policy':
        return <Shield className="h-5 w-5" />;
      case 'wave':
        return <Zap className="h-5 w-5" />;
      case 'crisis':
        return <AlertTriangle className="h-5 w-5" />;
      default:
        return <Calendar className="h-5 w-5" />;
    }
  };

  const getEventColor = (type: string) => {
    switch (type) {
      case 'milestone':
        return 'bg-green-500 text-white border-green-200';
      case 'policy':
        return 'bg-blue-500 text-white border-blue-200';
      case 'wave':
        return 'bg-red-500 text-white border-red-200';
      case 'crisis':
        return 'bg-orange-500 text-white border-orange-200';
      default:
        return 'bg-gray-500 text-white border-gray-200';
    }
  };

  const yearSections = {
    '2019': filteredEvents.filter(event => event.date.startsWith('2019')),
    '2020': filteredEvents.filter(event => event.date.startsWith('2020')),
    '2021': filteredEvents.filter(event => event.date.startsWith('2021')),
    '2022': filteredEvents.filter(event => event.date.startsWith('2022'))
  };

  const KeyMetrics = () => (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-xl p-6 text-white">
        <h3 className="text-lg font-semibold mb-2">Timeline Span</h3>
        <div className="text-3xl font-bold mb-1">3+</div>
        <p className="text-red-100 text-sm">Years of global pandemic</p>
      </div>
      
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl p-6 text-white">
        <h3 className="text-lg font-semibold mb-2">Countries Tracked</h3>
        <div className="text-3xl font-bold mb-1">8</div>
        <p className="text-blue-100 text-sm">Major countries analyzed</p>
      </div>
      
      <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-xl p-6 text-white">
        <h3 className="text-lg font-semibold mb-2">Key Events</h3>
        <div className="text-3xl font-bold mb-1">{globalTimelineEvents.length}</div>
        <p className="text-green-100 text-sm">Critical milestones documented</p>
      </div>

      <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl p-6 text-white">
        <h3 className="text-lg font-semibold mb-2">Global Impact</h3>
        <div className="text-3xl font-bold mb-1">Worldwide</div>
        <p className="text-purple-100 text-sm">Pandemic affected all nations</p>
      </div>
    </div>
  );

  const YearSection = ({ year, events }: { year: string; events: typeof globalTimelineEvents }) => {
    if (events.length === 0) return null;
    
    return (
      <div className="mb-12">
        <div className="flex items-center mb-6">
          <div className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-bold text-xl">
            {year}
          </div>
          <div className="flex-1 h-px bg-gray-300 ml-4"></div>
          <div className="ml-4 text-sm text-gray-600">
            {events.length} key events
          </div>
        </div>
        
        <div className="space-y-6">
          {events.map((event, index) => (
            <div key={index} className="flex items-start space-x-4">
              {/* Date */}
              <div className="flex-shrink-0 w-24 text-right">
                <div className="text-sm font-semibold text-gray-900">
                  {new Date(event.date).toLocaleDateString('en-US', { 
                    month: 'short', 
                    day: 'numeric' 
                  })}
                </div>
              </div>
              
              {/* Icon */}
              <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${getEventColor(event.type)}`}>
                {getEventIcon(event.type)}
              </div>
              
              {/* Content */}
              <div className="flex-1 bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {event.title}
                </h3>
                <p className="text-gray-600 mb-3">
                  {event.description}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      event.type === 'milestone' ? 'bg-green-100 text-green-800' :
                      event.type === 'policy' ? 'bg-blue-100 text-blue-800' :
                      event.type === 'wave' ? 'bg-red-100 text-red-800' :
                      event.type === 'crisis' ? 'bg-orange-100 text-orange-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                    </span>
                    <span className="text-xs text-gray-500">
                      {new Date(event.date).toLocaleDateString('en-US', { 
                        weekday: 'long',
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })}
                    </span>
                  </div>
                  <div className="flex items-center space-x-1">
                    {event.countries.map((country, idx) => (
                      <span key={idx} className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                        {country === 'global' ? 'Global' : 
                         countryInfo[country as keyof typeof countryInfo]?.name || country}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const EventTypeStats = () => {
    const typeStats = eventTypes.slice(1).map(type => ({
      type,
      count: globalTimelineEvents.filter(e => e.type === type).length,
      color: type === 'milestone' ? 'bg-green-500' :
             type === 'policy' ? 'bg-blue-500' :
             type === 'wave' ? 'bg-red-500' :
             type === 'crisis' ? 'bg-orange-500' : 'bg-gray-500'
    }));

    return (
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-2xl font-semibold text-gray-900 mb-6">Event Distribution</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {typeStats.map((stat) => (
            <div key={stat.type} className="text-center p-4 bg-gray-50 rounded-lg">
              <div className={`w-12 h-12 ${stat.color} rounded-full flex items-center justify-center mx-auto mb-3`}>
                {getEventIcon(stat.type)}
              </div>
              <h4 className="font-semibold text-gray-900 mb-1 capitalize">{stat.type}s</h4>
              <p className="text-2xl font-bold text-gray-900">{stat.count}</p>
              <p className="text-xs text-gray-600">events</p>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Global COVID-19 Timeline</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          A comprehensive chronological journey through the global COVID-19 pandemic, 
          highlighting key milestones, policy decisions, and critical events across major countries.
        </p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-3">
            <Filter className="h-5 w-5 text-indigo-600" />
            <h3 className="text-lg font-semibold text-gray-900">Filter Events</h3>
          </div>
          
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
            {/* Country Filter */}
            <div className="flex items-center space-x-2">
              <Globe className="h-4 w-4 text-gray-500" />
              <select
                value={selectedCountry}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="global">All Countries</option>
                {Object.entries(countryInfo).map(([code, info]) => (
                  <option key={code} value={code}>{info.name}</option>
                ))}
              </select>
            </div>

            {/* Event Type Filter */}
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-gray-500" />
              <select
                value={selectedEventType}
                onChange={(e) => setSelectedEventType(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="all">All Event Types</option>
                <option value="milestone">Milestones</option>
                <option value="policy">Policy Changes</option>
                <option value="wave">Pandemic Waves</option>
                <option value="crisis">Health Crises</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <KeyMetrics />

      {/* Event Type Statistics */}
      <EventTypeStats />

      {/* Timeline by Year */}
      <div className="relative">
        {/* Vertical line */}
        <div className="absolute left-24 top-0 bottom-0 w-px bg-gray-300"></div>
        
        {Object.entries(yearSections).map(([year, events]) => (
          <YearSection key={year} year={year} events={events} />
        ))}
      </div>

      {/* Legend */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Event Categories</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
              <TrendingUp className="h-4 w-4 text-white" />
            </div>
            <div>
              <span className="text-sm font-medium">Milestones</span>
              <p className="text-xs text-gray-500">Key achievements & records</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
              <Shield className="h-4 w-4 text-white" />
            </div>
            <div>
              <span className="text-sm font-medium">Policy Changes</span>
              <p className="text-xs text-gray-500">Government responses</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
              <Zap className="h-4 w-4 text-white" />
            </div>
            <div>
              <span className="text-sm font-medium">Pandemic Waves</span>
              <p className="text-xs text-gray-500">Surge periods</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
              <AlertTriangle className="h-4 w-4 text-white" />
            </div>
            <div>
              <span className="text-sm font-medium">Health Crises</span>
              <p className="text-xs text-gray-500">System strain events</p>
            </div>
          </div>
        </div>
      </div>

      {/* Results Summary */}
      {(selectedCountry !== 'global' || selectedEventType !== 'all') && (
        <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4">
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-indigo-600" />
            <span className="text-indigo-900 font-medium">
              Showing {filteredEvents.length} events
              {selectedCountry !== 'global' && ` for ${countryInfo[selectedCountry as keyof typeof countryInfo]?.name || selectedCountry}`}
              {selectedEventType !== 'all' && ` of type "${selectedEventType}"`}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

export default GlobalTimeline;