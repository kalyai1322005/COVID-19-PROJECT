import React from 'react';
import { Users, Skull, Heart, Activity, TrendingUp, TrendingDown } from 'lucide-react';
import { dailyData, stateData, vaccinationData } from '../data/covidData';

const Dashboard = () => {
  const latestData = dailyData[dailyData.length - 1];
  const previousData = dailyData[dailyData.length - 2];
  const latestVaccination = vaccinationData[vaccinationData.length - 1];
  
  const totalTests = 918471234; // Estimated total tests
  const positivityRate = ((latestData.cases / totalTests) * 100).toFixed(2);
  
  const getChangeIndicator = (current: number, previous: number) => {
    const change = current - previous;
    const isIncrease = change > 0;
    return {
      value: Math.abs(change).toLocaleString(),
      isIncrease,
      Icon: isIncrease ? TrendingUp : TrendingDown,
      colorClass: isIncrease ? 'text-red-500' : 'text-green-500'
    };
  };

  const casesChange = getChangeIndicator(latestData.cases, previousData.cases);
  const deathsChange = getChangeIndicator(latestData.deaths, previousData.deaths);
  const recoveredChange = getChangeIndicator(latestData.recovered, previousData.recovered);
  const activeChange = getChangeIndicator(latestData.active, previousData.active);

  const StatCard = ({ title, value, change, icon: Icon, bgColor, textColor }: any) => (
    <div className={`${bgColor} rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600 mb-1">{title}</p>
          <p className={`text-3xl font-bold ${textColor} mb-2`}>
            {value.toLocaleString()}
          </p>
          <div className={`flex items-center text-sm ${change.colorClass}`}>
            <change.Icon className="h-4 w-4 mr-1" />
            <span>{change.value} from yesterday</span>
          </div>
        </div>
        <div className={`p-3 rounded-full ${textColor.replace('text-', 'bg-').replace('-600', '-100')}`}>
          <Icon className={`h-8 w-8 ${textColor}`} />
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          COVID-19 India Dashboard
        </h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Comprehensive analysis of COVID-19 data in India from March 2020 to December 2022. 
          Track cases, deaths, recoveries, and vaccination progress across the nation.
        </p>
        <div className="mt-4 text-sm text-gray-500">
          Last Updated: {new Date(latestData.date).toLocaleDateString('en-IN', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </div>
      </div>

      {/* Key Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Cases"
          value={latestData.cases}
          change={casesChange}
          icon={Users}
          bgColor="bg-blue-50"
          textColor="text-blue-600"
        />
        <StatCard
          title="Deaths"
          value={latestData.deaths}
          change={deathsChange}
          icon={Skull}
          bgColor="bg-red-50"
          textColor="text-red-600"
        />
        <StatCard
          title="Recovered"
          value={latestData.recovered}
          change={recoveredChange}
          icon={Heart}
          bgColor="bg-green-50"
          textColor="text-green-600"
        />
        <StatCard
          title="Active Cases"
          value={latestData.active}
          change={activeChange}
          icon={Activity}
          bgColor="bg-orange-50"
          textColor="text-orange-600"
        />
      </div>

      {/* Additional Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recovery Rate</h3>
          <div className="text-3xl font-bold text-green-600 mb-2">
            {((latestData.recovered / latestData.cases) * 100).toFixed(1)}%
          </div>
          <p className="text-sm text-gray-600">
            {latestData.recovered.toLocaleString()} people recovered
          </p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Case Fatality Rate</h3>
          <div className="text-3xl font-bold text-red-600 mb-2">
            {((latestData.deaths / latestData.cases) * 100).toFixed(2)}%
          </div>
          <p className="text-sm text-gray-600">
            Among confirmed cases
          </p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Test Positivity Rate</h3>
          <div className="text-3xl font-bold text-blue-600 mb-2">
            {positivityRate}%
          </div>
          <p className="text-sm text-gray-600">
            Based on total tests conducted
          </p>
        </div>
      </div>

      {/* Vaccination Progress */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-2xl font-semibold text-gray-900 mb-6">Vaccination Progress</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">
              {latestVaccination.firstDose.toLocaleString()}
            </div>
            <p className="text-sm font-medium text-gray-600">First Dose</p>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
              <div 
                className="bg-blue-600 h-2 rounded-full" 
                style={{ width: `${(latestVaccination.firstDose / 1000000000) * 100}%` }}
              ></div>
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">
              {latestVaccination.secondDose.toLocaleString()}
            </div>
            <p className="text-sm font-medium text-gray-600">Second Dose</p>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
              <div 
                className="bg-green-600 h-2 rounded-full" 
                style={{ width: `${(latestVaccination.secondDose / 1000000000) * 100}%` }}
              ></div>
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">
              {latestVaccination.booster.toLocaleString()}
            </div>
            <p className="text-sm font-medium text-gray-600">Booster Dose</p>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
              <div 
                className="bg-purple-600 h-2 rounded-full" 
                style={{ width: `${(latestVaccination.booster / 250000000) * 100}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Top Affected States */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-2xl font-semibold text-gray-900 mb-6">Most Affected States</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-700">State</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-700">Total Cases</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-700">Deaths</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-700">Recovery Rate</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-700">Cases per 100K</th>
              </tr>
            </thead>
            <tbody>
              {stateData.slice(0, 8).map((state, index) => (
                <tr key={state.state} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4">
                    <div className="flex items-center">
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-indigo-100 text-indigo-600 text-xs font-medium mr-3">
                        {index + 1}
                      </span>
                      {state.state}
                    </div>
                  </td>
                  <td className="text-right py-3 px-4 font-medium">
                    {state.cases.toLocaleString()}
                  </td>
                  <td className="text-right py-3 px-4 text-red-600">
                    {state.deaths.toLocaleString()}
                  </td>
                  <td className="text-right py-3 px-4 text-green-600">
                    {((state.recovered / state.cases) * 100).toFixed(1)}%
                  </td>
                  <td className="text-right py-3 px-4">
                    {((state.cases / state.population) * 100000).toFixed(0)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;