import React, { useState } from 'react';
import { Users, Skull, Heart, Activity, TrendingUp, TrendingDown, Globe } from 'lucide-react';
import { globalDailyData, countryInfo, globalVaccinationData } from '../data/globalCovidData';

const GlobalDashboard = () => {
  const [selectedCountry, setSelectedCountry] = useState('india');
  
  const countries = Object.keys(globalDailyData);
  const currentData = globalDailyData[selectedCountry as keyof typeof globalDailyData];
  const latestData = currentData[currentData.length - 1];
  const previousData = currentData[currentData.length - 2];
  const countryDetails = countryInfo[selectedCountry as keyof typeof countryInfo];
  
  const getChangeIndicator = (current: number, previous: number) => {
    const change = current - previous;
    const isIncrease = change > 0;
    return {
      value: Math.abs(change).toLocaleString(),
      isIncrease,
      Icon: isIncrease ? TrendingUp : TrendingDown,
      colorClass: isIncrease ? 'text-red-500' : 'text-green-500'
    };
  };

  const casesChange = getChangeIndicator(latestData.cases, previousData.cases);
  const deathsChange = getChangeIndicator(latestData.deaths, previousData.deaths);
  const recoveredChange = getChangeIndicator(latestData.recovered, previousData.recovered);
  const activeChange = getChangeIndicator(latestData.active, previousData.active);

  const StatCard = ({ title, value, change, icon: Icon, bgColor, textColor }: any) => (
    <div className={`${bgColor} rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600 mb-1">{title}</p>
          <p className={`text-3xl font-bold ${textColor} mb-2`}>
            {value.toLocaleString()}
          </p>
          <div className={`flex items-center text-sm ${change.colorClass}`}>
            <change.Icon className="h-4 w-4 mr-1" />
            <span>{change.value} from previous period</span>
          </div>
        </div>
        <div className={`p-3 rounded-full ${textColor.replace('text-', 'bg-').replace('-600', '-100')}`}>
          <Icon className={`h-8 w-8 ${textColor}`} />
        </div>
      </div>
    </div>
  );

  // Global totals calculation
  const globalTotals = countries.reduce((totals, country) => {
    const countryData = globalDailyData[country as keyof typeof globalDailyData];
    const latest = countryData[countryData.length - 1];
    return {
      cases: totals.cases + latest.cases,
      deaths: totals.deaths + latest.deaths,
      recovered: totals.recovered + latest.recovered,
      active: totals.active + latest.active
    };
  }, { cases: 0, deaths: 0, recovered: 0, active: 0 });

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Global COVID-19 Dashboard
        </h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Comprehensive analysis of COVID-19 data across major countries from 2020 to 2022. 
          Compare cases, deaths, recoveries, and vaccination progress globally.
        </p>
      </div>

      {/* Country Selector */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-3">
            <Globe className="h-6 w-6 text-indigo-600" />
            <h3 className="text-lg font-semibold text-gray-900">Select Country</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {countries.map((country) => (
              <button
                key={country}
                onClick={() => setSelectedCountry(country)}
                className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors duration-200 ${
                  selectedCountry === country
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {countryInfo[country as keyof typeof countryInfo].name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Selected Country Info */}
      <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2">{countryDetails.name}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
              <div>
                <span className="text-indigo-200">Capital:</span>
                <span className="ml-2 font-medium">{countryDetails.capital}</span>
              </div>
              <div>
                <span className="text-indigo-200">Continent:</span>
                <span className="ml-2 font-medium">{countryDetails.continent}</span>
              </div>
              <div>
                <span className="text-indigo-200">Population:</span>
                <span className="ml-2 font-medium">{countryDetails.population.toLocaleString()}</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-indigo-200">Last Updated</div>
            <div className="font-medium">
              {new Date(latestData.date).toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Key Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Cases"
          value={latestData.cases}
          change={casesChange}
          icon={Users}
          bgColor="bg-blue-50"
          textColor="text-blue-600"
        />
        <StatCard
          title="Deaths"
          value={latestData.deaths}
          change={deathsChange}
          icon={Skull}
          bgColor="bg-red-50"
          textColor="text-red-600"
        />
        <StatCard
          title="Recovered"
          value={latestData.recovered}
          change={recoveredChange}
          icon={Heart}
          bgColor="bg-green-50"
          textColor="text-green-600"
        />
        <StatCard
          title="Active Cases"
          value={latestData.active}
          change={activeChange}
          icon={Activity}
          bgColor="bg-orange-50"
          textColor="text-orange-600"
        />
      </div>

      {/* Additional Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recovery Rate</h3>
          <div className="text-3xl font-bold text-green-600 mb-2">
            {((latestData.recovered / latestData.cases) * 100).toFixed(1)}%
          </div>
          <p className="text-sm text-gray-600">
            {latestData.recovered.toLocaleString()} people recovered
          </p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Case Fatality Rate</h3>
          <div className="text-3xl font-bold text-red-600 mb-2">
            {((latestData.deaths / latestData.cases) * 100).toFixed(2)}%
          </div>
          <p className="text-sm text-gray-600">
            Among confirmed cases
          </p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Cases per 100K</h3>
          <div className="text-3xl font-bold text-blue-600 mb-2">
            {((latestData.cases / countryDetails.population) * 100000).toFixed(0)}
          </div>
          <p className="text-sm text-gray-600">
            Population-adjusted rate
          </p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Infection Rate</h3>
          <div className="text-3xl font-bold text-purple-600 mb-2">
            {((latestData.cases / countryDetails.population) * 100).toFixed(1)}%
          </div>
          <p className="text-sm text-gray-600">
            Of total population
          </p>
        </div>
      </div>

      {/* Global Summary */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-2xl font-semibold text-gray-900 mb-6">Global Summary (8 Major Countries)</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">
              {globalTotals.cases.toLocaleString()}
            </div>
            <p className="text-sm font-medium text-gray-600">Total Cases</p>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-red-600 mb-2">
              {globalTotals.deaths.toLocaleString()}
            </div>
            <p className="text-sm font-medium text-gray-600">Total Deaths</p>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">
              {globalTotals.recovered.toLocaleString()}
            </div>
            <p className="text-sm font-medium text-gray-600">Total Recovered</p>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-orange-600 mb-2">
              {globalTotals.active.toLocaleString()}
            </div>
            <p className="text-sm font-medium text-gray-600">Active Cases</p>
          </div>
        </div>
      </div>

      {/* Country Rankings */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-2xl font-semibold text-gray-900 mb-6">Country Rankings</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Rank</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Country</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-700">Total Cases</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-700">Deaths</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-700">Recovery Rate</th>
                <th className="text-right py-3 px-4 font-semibold text-gray-700">Cases per 100K</th>
              </tr>
            </thead>
            <tbody>
              {countries
                .map(country => {
                  const data = globalDailyData[country as keyof typeof globalDailyData];
                  const latest = data[data.length - 1];
                  const info = countryInfo[country as keyof typeof countryInfo];
                  return {
                    country,
                    ...latest,
                    info,
                    casesPerHundredK: (latest.cases / info.population) * 100000
                  };
                })
                .sort((a, b) => b.cases - a.cases)
                .map((country, index) => (
                  <tr key={country.country} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-indigo-100 text-indigo-600 text-xs font-medium">
                        {index + 1}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-medium">{country.info.name}</td>
                    <td className="text-right py-3 px-4 font-medium">
                      {country.cases.toLocaleString()}
                    </td>
                    <td className="text-right py-3 px-4 text-red-600">
                      {country.deaths.toLocaleString()}
                    </td>
                    <td className="text-right py-3 px-4 text-green-600">
                      {((country.recovered / country.cases) * 100).toFixed(1)}%
                    </td>
                    <td className="text-right py-3 px-4">
                      {country.casesPerHundredK.toFixed(0)}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default GlobalDashboard;