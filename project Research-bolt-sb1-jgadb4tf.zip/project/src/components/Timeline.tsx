import React from 'react';
import { Calendar, AlertTriangle, Shield, Zap, Heart, TrendingUp } from 'lucide-react';
import { timelineEvents } from '../data/covidData';

const Timeline = () => {
  const getEventIcon = (type: string) => {
    switch (type) {
      case 'milestone':
        return <TrendingUp className="h-5 w-5" />;
      case 'policy':
        return <Shield className="h-5 w-5" />;
      case 'wave':
        return <Zap className="h-5 w-5" />;
      case 'crisis':
        return <AlertTriangle className="h-5 w-5" />;
      default:
        return <Calendar className="h-5 w-5" />;
    }
  };

  const getEventColor = (type: string) => {
    switch (type) {
      case 'milestone':
        return 'bg-green-500 text-white border-green-200';
      case 'policy':
        return 'bg-blue-500 text-white border-blue-200';
      case 'wave':
        return 'bg-red-500 text-white border-red-200';
      case 'crisis':
        return 'bg-orange-500 text-white border-orange-200';
      default:
        return 'bg-gray-500 text-white border-gray-200';
    }
  };

  const yearSections = {
    '2020': timelineEvents.filter(event => event.date.startsWith('2020')),
    '2021': timelineEvents.filter(event => event.date.startsWith('2021')),
    '2022': timelineEvents.filter(event => event.date.startsWith('2022'))
  };

  const KeyMetrics = () => (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-xl p-6 text-white">
        <h3 className="text-lg font-semibold mb-2">Timeline Span</h3>
        <div className="text-3xl font-bold mb-1">1,029</div>
        <p className="text-red-100 text-sm">Days from first case to end of 2022</p>
      </div>
      
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl p-6 text-white">
        <h3 className="text-lg font-semibold mb-2">Major Waves</h3>
        <div className="text-3xl font-bold mb-1">3</div>
        <p className="text-blue-100 text-sm">Distinct pandemic waves identified</p>
      </div>
      
      <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-xl p-6 text-white">
        <h3 className="text-lg font-semibold mb-2">Key Milestones</h3>
        <div className="text-3xl font-bold mb-1">{timelineEvents.length}</div>
        <p className="text-green-100 text-sm">Critical events documented</p>
      </div>
    </div>
  );

  const YearSection = ({ year, events }: { year: string; events: typeof timelineEvents }) => (
    <div className="mb-12">
      <div className="flex items-center mb-6">
        <div className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-bold text-xl">
          {year}
        </div>
        <div className="flex-1 h-px bg-gray-300 ml-4"></div>
        <div className="ml-4 text-sm text-gray-600">
          {events.length} key events
        </div>
      </div>
      
      <div className="space-y-6">
        {events.map((event, index) => (
          <div key={index} className="flex items-start space-x-4">
            {/* Date */}
            <div className="flex-shrink-0 w-24 text-right">
              <div className="text-sm font-semibold text-gray-900">
                {new Date(event.date).toLocaleDateString('en-IN', { 
                  month: 'short', 
                  day: 'numeric' 
                })}
              </div>
            </div>
            
            {/* Icon */}
            <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${getEventColor(event.type)}`}>
              {getEventIcon(event.type)}
            </div>
            
            {/* Content */}
            <div className="flex-1 bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {event.title}
              </h3>
              <p className="text-gray-600 mb-3">
                {event.description}
              </p>
              <div className="flex items-center space-x-2">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  event.type === 'milestone' ? 'bg-green-100 text-green-800' :
                  event.type === 'policy' ? 'bg-blue-100 text-blue-800' :
                  event.type === 'wave' ? 'bg-red-100 text-red-800' :
                  event.type === 'crisis' ? 'bg-orange-100 text-orange-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                </span>
                <span className="text-xs text-gray-500">
                  {new Date(event.date).toLocaleDateString('en-IN', { 
                    weekday: 'long',
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">COVID-19 Timeline</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          A chronological journey through India's COVID-19 pandemic from the first case 
          to the end of 2022, highlighting key milestones, policy decisions, and critical events.
        </p>
      </div>

      {/* Key Metrics */}
      <KeyMetrics />

      {/* Wave Overview */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-2xl font-semibold text-gray-900 mb-6">Wave Pattern Analysis</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-4 bg-red-50 rounded-lg">
            <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-3">
              <Zap className="h-6 w-6 text-white" />
            </div>
            <h4 className="font-semibold text-red-900 mb-2">First Wave</h4>
            <p className="text-sm text-red-700">March - December 2020</p>
            <p className="text-xs text-red-600 mt-1">Peak: 97,894 daily cases (Sept 16)</p>
          </div>
          
          <div className="text-center p-4 bg-orange-50 rounded-lg">
            <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-3">
              <AlertTriangle className="h-6 w-6 text-white" />
            </div>
            <h4 className="font-semibold text-orange-900 mb-2">Second Wave</h4>
            <p className="text-sm text-orange-700">March - July 2021</p>
            <p className="text-xs text-orange-600 mt-1">Peak: 414,188 daily cases (May 7)</p>
          </div>
          
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-3">
              <TrendingUp className="h-6 w-6 text-white" />
            </div>
            <h4 className="font-semibold text-yellow-900 mb-2">Third Wave</h4>
            <p className="text-sm text-yellow-700">December 2021 - March 2022</p>
            <p className="text-xs text-yellow-600 mt-1">Peak: 347,254 daily cases (Jan 21)</p>
          </div>
        </div>
      </div>

      {/* Timeline by Year */}
      <div className="relative">
        {/* Vertical line */}
        <div className="absolute left-24 top-0 bottom-0 w-px bg-gray-300"></div>
        
        {Object.entries(yearSections).map(([year, events]) => (
          <YearSection key={year} year={year} events={events} />
        ))}
      </div>

      {/* Legend */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Event Categories</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
              <TrendingUp className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-medium">Milestones</span>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
              <Shield className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-medium">Policy Changes</span>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
              <Zap className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-medium">Pandemic Waves</span>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
              <AlertTriangle className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-medium">Health Crises</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Timeline;