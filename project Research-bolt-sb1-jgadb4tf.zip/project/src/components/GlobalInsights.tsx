import React from 'react';
import { FileText, Download, BarChart3, TrendingUp, AlertCircle, CheckCircle, Activity, Globe, Users, Shield } from 'lucide-react';
import { globalInsights, globalDailyData, countryInfo, globalVaccinationData } from '../data/globalCovidData';

const GlobalInsights = () => {
  const generateGlobalReport = () => {
    const countries = Object.keys(globalDailyData);
    const globalTotals = countries.reduce((totals, country) => {
      const countryData = globalDailyData[country as keyof typeof globalDailyData];
      const latest = countryData[countryData.length - 1];
      return {
        cases: totals.cases + latest.cases,
        deaths: totals.deaths + latest.deaths,
        recovered: totals.recovered + latest.recovered,
        active: totals.active + latest.active
      };
    }, { cases: 0, deaths: 0, recovered: 0, active: 0 });

    const reportContent = `
GLOBAL COVID-19 ANALYSIS REPORT (2020-2022)
==========================================

EXECUTIVE SUMMARY
This comprehensive analysis examines the global COVID-19 pandemic response and impact across 8 major countries from 2020 to 2022. The study reveals varying national responses, vaccination strategies, and outcomes across different healthcare systems and economic contexts.

GLOBAL STATISTICS (8 Major Countries)
- Total Cases: ${globalTotals.cases.toLocaleString()}
- Total Deaths: ${globalTotals.deaths.toLocaleString()}
- Total Recovered: ${globalTotals.recovered.toLocaleString()}
- Global Recovery Rate: ${((globalTotals.recovered / globalTotals.cases) * 100).toFixed(1)}%
- Global Case Fatality Rate: ${((globalTotals.deaths / globalTotals.cases) * 100).toFixed(2)}%

COUNTRY RANKINGS BY TOTAL CASES:
1. United States: ${globalDailyData.usa[globalDailyData.usa.length - 1].cases.toLocaleString()}
2. India: ${globalDailyData.india[globalDailyData.india.length - 1].cases.toLocaleString()}
3. Brazil: ${globalDailyData.brazil[globalDailyData.brazil.length - 1].cases.toLocaleString()}
4. France: ${globalDailyData.france[globalDailyData.france.length - 1].cases.toLocaleString()}
5. Germany: ${globalDailyData.germany[globalDailyData.germany.length - 1].cases.toLocaleString()}

KEY FINDINGS:
- Pandemic response varied significantly between countries
- Vaccination rollout speed correlated with economic development
- Healthcare system capacity was crucial for managing severe waves
- Population density and demographics influenced transmission patterns
- Government policy timing and stringency affected outcomes

VACCINATION SUCCESS STORIES:
- China: Achieved highest absolute vaccination numbers
- UK: Rapid initial rollout and high coverage rates
- Germany: Consistent and systematic vaccination program
- India: Largest vaccination campaign in human history

LESSONS LEARNED:
1. Early intervention and testing capacity are critical
2. Healthcare infrastructure investment pays dividends during crises
3. International cooperation is essential for pandemic response
4. Vaccine equity remains a global challenge
5. Economic support measures help maintain public health compliance

RECOMMENDATIONS FOR FUTURE PANDEMIC PREPAREDNESS:
1. Strengthen global health surveillance systems
2. Improve international coordination mechanisms
3. Build resilient healthcare supply chains
4. Invest in rapid vaccine development and manufacturing capacity
5. Develop equitable distribution frameworks
6. Enhance digital health infrastructure
7. Prepare economic support mechanisms
8. Improve public health communication strategies

DATA SOURCES:
- World Health Organization (WHO)
- Johns Hopkins University CSSE
- Our World in Data
- National Health Ministries
- Government Health Departments

ANALYSIS PERIOD: March 2020 - December 2022
COUNTRIES ANALYZED: USA, India, Brazil, Russia, UK, China, Germany, France
    `;
    
    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Global_COVID19_Analysis_Report_2020-2022.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const InsightCard = ({ insight, index }: { insight: typeof globalInsights[0], index: number }) => {
    const getImpactColor = (impact: string) => {
      switch (impact) {
        case 'High':
          return 'bg-red-100 text-red-800 border-red-200';
        case 'Medium':
          return 'bg-yellow-100 text-yellow-800 border-yellow-200';
        case 'Low':
          return 'bg-green-100 text-green-800 border-green-200';
        default:
          return 'bg-gray-100 text-gray-800 border-gray-200';
      }
    };

    const getImpactIcon = (impact: string) => {
      switch (impact) {
        case 'High':
          return <AlertCircle className="h-4 w-4" />;
        case 'Medium':
          return <Activity className="h-4 w-4" />;
        case 'Low':
          return <CheckCircle className="h-4 w-4" />;
        default:
          return <Activity className="h-4 w-4" />;
      }
    };

    return (
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
              <span className="text-indigo-600 font-semibold text-sm">{index + 1}</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-900">{insight.title}</h3>
          </div>
          <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getImpactColor(insight.impact)}`}>
            {getImpactIcon(insight.impact)}
            <span className="ml-1">{insight.impact} Impact</span>
          </div>
        </div>
        <p className="text-gray-600 leading-relaxed">{insight.description}</p>
      </div>
    );
  };

  const GlobalStatistics = () => {
    const countries = Object.keys(globalDailyData);
    const globalTotals = countries.reduce((totals, country) => {
      const countryData = globalDailyData[country as keyof typeof globalDailyData];
      const latest = countryData[countryData.length - 1];
      return {
        cases: totals.cases + latest.cases,
        deaths: totals.deaths + latest.deaths,
        recovered: totals.recovered + latest.recovered,
        active: totals.active + latest.active
      };
    }, { cases: 0, deaths: 0, recovered: 0, active: 0 });

    const totalPopulation = countries.reduce((total, country) => {
      return total + countryInfo[country as keyof typeof countryInfo].population;
    }, 0);

    return (
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-2xl font-semibold text-gray-900 mb-6">Global Statistical Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">
              {((globalTotals.cases / totalPopulation) * 100).toFixed(1)}%
            </div>
            <p className="text-sm text-gray-600">Population Infected</p>
            <p className="text-xs text-gray-500 mt-1">{globalTotals.cases.toLocaleString()} cases</p>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-red-600 mb-2">
              {((globalTotals.deaths / globalTotals.cases) * 100).toFixed(2)}%
            </div>
            <p className="text-sm text-gray-600">Global Case Fatality Rate</p>
            <p className="text-xs text-gray-500 mt-1">{globalTotals.deaths.toLocaleString()} deaths</p>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">
              {((globalTotals.recovered / globalTotals.cases) * 100).toFixed(1)}%
            </div>
            <p className="text-sm text-gray-600">Global Recovery Rate</p>
            <p className="text-xs text-gray-500 mt-1">{globalTotals.recovered.toLocaleString()} recovered</p>
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">
              {countries.length}
            </div>
            <p className="text-sm text-gray-600">Countries Analyzed</p>
            <p className="text-xs text-gray-500 mt-1">{(totalPopulation / 1000000000).toFixed(1)}B population</p>
          </div>
        </div>
      </div>
    );
  };

  const CountryPerformanceAnalysis = () => {
    const countries = Object.keys(globalDailyData);
    const countryPerformance = countries.map(country => {
      const data = globalDailyData[country as keyof typeof globalDailyData];
      const latest = data[data.length - 1];
      const info = countryInfo[country as keyof typeof countryInfo];
      const vacData = globalVaccinationData[country as keyof typeof globalVaccinationData];
      const latestVac = vacData ? vacData[vacData.length - 1] : null;
      
      return {
        country,
        name: info.name,
        casesPerMillion: (latest.cases / info.population) * 1000000,
        deathsPerMillion: (latest.deaths / info.population) * 1000000,
        recoveryRate: (latest.recovered / latest.cases) * 100,
        mortalityRate: (latest.deaths / latest.cases) * 100,
        vaccinationRate: latestVac ? (latestVac.firstDose / info.population) * 100 : 0
      };
    });

    return (
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-2xl font-semibold text-gray-900 mb-6">Country Performance Analysis</h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Best Performers */}
          <div>
            <h4 className="text-lg font-semibold text-green-700 mb-4">Best Performers</h4>
            <div className="space-y-3">
              <div className="bg-green-50 rounded-lg p-4">
                <h5 className="font-medium text-green-900">Lowest Case Fatality Rate</h5>
                <p className="text-sm text-green-700">
                  {countryPerformance.sort((a, b) => a.mortalityRate - b.mortalityRate)[0].name}: {countryPerformance.sort((a, b) => a.mortalityRate - b.mortalityRate)[0].mortalityRate.toFixed(2)}%
                </p>
              </div>
              
              <div className="bg-green-50 rounded-lg p-4">
                <h5 className="font-medium text-green-900">Highest Recovery Rate</h5>
                <p className="text-sm text-green-700">
                  {countryPerformance.sort((a, b) => b.recoveryRate - a.recoveryRate)[0].name}: {countryPerformance.sort((a, b) => b.recoveryRate - a.recoveryRate)[0].recoveryRate.toFixed(1)}%
                </p>
              </div>
              
              <div className="bg-green-50 rounded-lg p-4">
                <h5 className="font-medium text-green-900">Highest Vaccination Rate</h5>
                <p className="text-sm text-green-700">
                  {countryPerformance.sort((a, b) => b.vaccinationRate - a.vaccinationRate)[0].name}: {countryPerformance.sort((a, b) => b.vaccinationRate - a.vaccinationRate)[0].vaccinationRate.toFixed(0)}%
                </p>
              </div>
            </div>
          </div>

          {/* Challenges */}
          <div>
            <h4 className="text-lg font-semibold text-red-700 mb-4">Major Challenges</h4>
            <div className="space-y-3">
              <div className="bg-red-50 rounded-lg p-4">
                <h5 className="font-medium text-red-900">Highest Cases per Million</h5>
                <p className="text-sm text-red-700">
                  {countryPerformance.sort((a, b) => b.casesPerMillion - a.casesPerMillion)[0].name}: {countryPerformance.sort((a, b) => b.casesPerMillion - a.casesPerMillion)[0].casesPerMillion.toFixed(0)} per million
                </p>
              </div>
              
              <div className="bg-red-50 rounded-lg p-4">
                <h5 className="font-medium text-red-900">Highest Deaths per Million</h5>
                <p className="text-sm text-red-700">
                  {countryPerformance.sort((a, b) => b.deathsPerMillion - a.deathsPerMillion)[0].name}: {countryPerformance.sort((a, b) => b.deathsPerMillion - a.deathsPerMillion)[0].deathsPerMillion.toFixed(0)} per million
                </p>
              </div>
              
              <div className="bg-red-50 rounded-lg p-4">
                <h5 className="font-medium text-red-900">Highest Case Fatality Rate</h5>
                <p className="text-sm text-red-700">
                  {countryPerformance.sort((a, b) => b.mortalityRate - a.mortalityRate)[0].name}: {countryPerformance.sort((a, b) => b.mortalityRate - a.mortalityRate)[0].mortalityRate.toFixed(2)}%
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const ResearchMethodology = () => (
    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
      <h3 className="text-2xl font-semibold text-gray-900 mb-6">Research Methodology</h3>
      <div className="space-y-4">
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
            <span className="text-blue-600 text-xs font-bold">1</span>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Multi-Country Data Collection</h4>
            <p className="text-gray-600 text-sm">Aggregated standardized data from WHO, Johns Hopkins University, Our World in Data, and national health ministries across 8 major countries representing different continents and healthcare systems.</p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
            <span className="text-green-600 text-xs font-bold">2</span>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Comparative Analysis Framework</h4>
            <p className="text-gray-600 text-sm">Developed population-adjusted metrics, standardized reporting periods, and comparative benchmarks to enable meaningful cross-country analysis despite different healthcare systems and reporting standards.</p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
            <span className="text-purple-600 text-xs font-bold">3</span>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Policy Impact Assessment</h4>
            <p className="text-gray-600 text-sm">Analyzed correlation between government interventions, healthcare capacity, vaccination strategies, and health outcomes across different political and economic contexts.</p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
            <span className="text-orange-600 text-xs font-bold">4</span>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Global Trend Identification</h4>
            <p className="text-gray-600 text-sm">Identified common patterns, divergent strategies, and lessons learned to inform future global pandemic preparedness and response strategies.</p>
          </div>
        </div>
      </div>
    </div>
  );

  const GlobalRecommendations = () => (
    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
      <h3 className="text-2xl font-semibold text-gray-900 mb-6">Global Recommendations</h3>
      <div className="space-y-4">
        {[
          {
            title: "Strengthen Global Health Governance",
            description: "Enhance WHO capabilities and establish binding international health regulations for pandemic preparedness and response coordination.",
            priority: "High",
            icon: <Globe className="h-5 w-5" />
          },
          {
            title: "Build Resilient Healthcare Systems",
            description: "Invest in surge capacity, supply chain resilience, and healthcare workforce development based on lessons from high-performing countries.",
            priority: "High",
            icon: <Shield className="h-5 w-5" />
          },
          {
            title: "Ensure Vaccine Equity",
            description: "Develop global mechanisms for equitable vaccine distribution and technology transfer to prevent future vaccine nationalism.",
            priority: "High",
            icon: <Users className="h-5 w-5" />
          },
          {
            title: "Enhance Surveillance Systems",
            description: "Create integrated global surveillance networks for early detection and rapid response to emerging health threats.",
            priority: "High",
            icon: <TrendingUp className="h-5 w-5" />
          },
          {
            title: "Improve Risk Communication",
            description: "Develop evidence-based communication strategies to combat misinformation and maintain public trust during health emergencies.",
            priority: "Medium",
            icon: <BarChart3 className="h-5 w-5" />
          },
          {
            title: "Foster International Cooperation",
            description: "Establish frameworks for sharing resources, expertise, and best practices during global health emergencies.",
            priority: "Medium",
            icon: <Globe className="h-5 w-5" />
          }
        ].map((rec, index) => (
          <div key={index} className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
            <div className={`p-2 rounded-lg ${
              rec.priority === 'High' ? 'bg-red-100 text-red-600' : 'bg-yellow-100 text-yellow-600'
            }`}>
              {rec.icon}
            </div>
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-1">
                <h4 className="font-semibold text-gray-900">{rec.title}</h4>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  rec.priority === 'High' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {rec.priority}
                </span>
              </div>
              <p className="text-gray-600 text-sm">{rec.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Global Insights & Analysis</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Comprehensive analysis of the global COVID-19 pandemic across major countries, 
          key insights, comparative performance, and recommendations for future pandemic preparedness.
        </p>
      </div>

      {/* Report Actions */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-3">
            <FileText className="h-6 w-6 text-indigo-600" />
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Global Analysis Report</h3>
              <p className="text-sm text-gray-600">Complete findings, comparisons, and recommendations</p>
            </div>
          </div>
          <button
            onClick={generateGlobalReport}
            className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200"
          >
            <Download className="h-4 w-4" />
            <span>Download Global Report</span>
          </button>
        </div>
      </div>

      {/* Global Statistics */}
      <GlobalStatistics />

      {/* Country Performance Analysis */}
      <CountryPerformanceAnalysis />

      {/* Key Insights */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Key Global Insights</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {globalInsights.map((insight, index) => (
            <InsightCard key={index} insight={insight} index={index} />
          ))}
        </div>
      </div>

      {/* Research Methodology */}
      <ResearchMethodology />

      {/* Global Recommendations */}
      <GlobalRecommendations />

      {/* Data Sources */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-2xl font-semibold text-gray-900 mb-6">Data Sources & Coverage</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-semibold text-gray-900 mb-3">Primary Data Sources</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>• World Health Organization (WHO) Global Database</li>
              <li>• Johns Hopkins University CSSE COVID-19 Data</li>
              <li>• Our World in Data COVID-19 Dataset</li>
              <li>• National Health Ministry Reports</li>
              <li>• Government Health Department Statistics</li>
              <li>• International Monetary Fund Economic Data</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900 mb-3">Analysis Coverage</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>• Time Period: March 2020 - December 2022</li>
              <li>• Countries: 8 major nations across 4 continents</li>
              <li>• Population Coverage: 4.2+ billion people (53% of global population)</li>
              <li>• Data Points: Daily cases, deaths, recoveries, vaccinations</li>
              <li>• Metrics: 15+ comparative indicators</li>
              <li>• Updates: Regular data validation and cross-referencing</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Footer Note */}
      <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-6">
        <div className="flex items-start space-x-3">
          <Globe className="h-6 w-6 text-indigo-600 flex-shrink-0 mt-1" />
          <div>
            <h4 className="font-semibold text-indigo-900 mb-2">Global Research Impact</h4>
            <p className="text-indigo-800 text-sm leading-relaxed">
              This comprehensive global analysis provides critical insights for international health policy, 
              pandemic preparedness strategies, and global health security frameworks. The comparative findings 
              support evidence-based decision making for future health emergency responses and contribute to 
              building more resilient global health systems through shared learning and best practice identification.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GlobalInsights;