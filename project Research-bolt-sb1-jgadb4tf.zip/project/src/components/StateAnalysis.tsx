import React, { useState } from 'react';
import { MapPin, TrendingUp, Users, Skull, Heart, Search } from 'lucide-react';
import { stateData } from '../data/covidData';

const StateAnalysis = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('cases');
  const [sortOrder, setSortOrder] = useState('desc');

  const filteredStates = stateData
    .filter(state => 
      state.state.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      let aValue, bValue;
      
      switch (sortBy) {
        case 'cases':
          aValue = a.cases;
          bValue = b.cases;
          break;
        case 'deaths':
          aValue = a.deaths;
          bValue = b.deaths;
          break;
        case 'recovery':
          aValue = (a.recovered / a.cases) * 100;
          bValue = (b.recovered / b.cases) * 100;
          break;
        case 'population':
          aValue = a.population;
          bValue = b.population;
          break;
        case 'casesPerLakh':
          aValue = (a.cases / a.population) * 100000;
          bValue = (b.cases / b.population) * 100000;
          break;
        default:
          aValue = a.cases;
          bValue = b.cases;
      }
      
      return sortOrder === 'desc' ? bValue - aValue : aValue - bValue;
    });

  const StateCard = ({ state }: { state: typeof stateData[0] }) => {
    const recoveryRate = ((state.recovered / state.cases) * 100).toFixed(1);
    const mortalityRate = ((state.deaths / state.cases) * 100).toFixed(2);
    const casesPerLakh = ((state.cases / state.population) * 100000).toFixed(0);
    
    return (
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-indigo-100 rounded-lg">
              <MapPin className="h-5 w-5 text-indigo-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900">{state.state}</h3>
          </div>
          <div className="text-sm text-gray-500">
            Pop: {(state.population / 1000000).toFixed(1)}M
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-blue-50 rounded-lg p-3">
              <div className="flex items-center space-x-2 mb-1">
                <Users className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-700">Total Cases</span>
              </div>
              <div className="text-lg font-bold text-blue-900">
                {state.cases.toLocaleString()}
              </div>
              <div className="text-xs text-blue-600">
                {casesPerLakh} per 100K
              </div>
            </div>
            
            <div className="bg-red-50 rounded-lg p-3">
              <div className="flex items-center space-x-2 mb-1">
                <Skull className="h-4 w-4 text-red-600" />
                <span className="text-sm font-medium text-red-700">Deaths</span>
              </div>
              <div className="text-lg font-bold text-red-900">
                {state.deaths.toLocaleString()}
              </div>
              <div className="text-xs text-red-600">
                {mortalityRate}% CFR
              </div>
            </div>
          </div>
          
          <div className="bg-green-50 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <Heart className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium text-green-700">Recovery</span>
              </div>
              <span className="text-sm font-bold text-green-900">{recoveryRate}%</span>
            </div>
            <div className="w-full bg-green-200 rounded-full h-2">
              <div 
                className="bg-green-600 h-2 rounded-full transition-all duration-500" 
                style={{ width: `${recoveryRate}%` }}
              ></div>
            </div>
            <div className="text-xs text-green-600 mt-1">
              {state.recovered.toLocaleString()} recovered
            </div>
          </div>
        </div>
      </div>
    );
  };

  const getSeverityColor = (casesPerLakh: number) => {
    if (casesPerLakh > 8000) return 'bg-red-500';
    if (casesPerLakh > 6000) return 'bg-orange-500';
    if (casesPerLakh > 4000) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">State-wise Analysis</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Detailed analysis of COVID-19 impact across Indian states and union territories. 
          Compare cases, deaths, recovery rates, and population-adjusted metrics.
        </p>
      </div>

      {/* Controls */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search states..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-full lg:w-64 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>
          
          {/* Sort Options */}
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-gray-700">Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="cases">Total Cases</option>
              <option value="deaths">Deaths</option>
              <option value="recovery">Recovery Rate</option>
              <option value="casesPerLakh">Cases per 100K</option>
              <option value="population">Population</option>
            </select>
            
            <button
              onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')}
              className="flex items-center space-x-1 px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors duration-200 text-sm"
            >
              <TrendingUp className={`h-4 w-4 transition-transform duration-200 ${sortOrder === 'asc' ? 'rotate-180' : ''}`} />
              <span>{sortOrder === 'desc' ? 'High to Low' : 'Low to High'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl p-6 text-white">
          <h3 className="text-lg font-semibold mb-2">Total States/UTs</h3>
          <div className="text-3xl font-bold">{stateData.length}</div>
          <p className="text-blue-100 text-sm">Analyzed regions</p>
        </div>
        
        <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-xl p-6 text-white">
          <h3 className="text-lg font-semibold mb-2">Most Affected</h3>
          <div className="text-xl font-bold">{stateData[0].state}</div>
          <p className="text-red-100 text-sm">{stateData[0].cases.toLocaleString()} cases</p>
        </div>
        
        <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-xl p-6 text-white">
          <h3 className="text-lg font-semibold mb-2">Best Recovery</h3>
          <div className="text-xl font-bold">
            {stateData
              .map(s => ({ state: s.state, rate: (s.recovered / s.cases) * 100 }))
              .sort((a, b) => b.rate - a.rate)[0].state}
          </div>
          <p className="text-green-100 text-sm">
            {stateData
              .map(s => (s.recovered / s.cases) * 100)
              .sort((a, b) => b - a)[0].toFixed(1)}% recovery
          </p>
        </div>
        
        <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl p-6 text-white">
          <h3 className="text-lg font-semibold mb-2">Population Impact</h3>
          <div className="text-xl font-bold">
            {((stateData.reduce((sum, s) => sum + s.cases, 0) / 
               stateData.reduce((sum, s) => sum + s.population, 0)) * 100).toFixed(1)}%
          </div>
          <p className="text-purple-100 text-sm">Average infection rate</p>
        </div>
      </div>

      {/* Heat Map Style Overview */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Impact Severity Map</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {stateData.map((state) => {
            const casesPerLakh = (state.cases / state.population) * 100000;
            const colorClass = getSeverityColor(casesPerLakh);
            
            return (
              <div
                key={state.state}
                className={`${colorClass} rounded-lg p-3 text-white text-center transition-transform duration-200 hover:scale-105 cursor-pointer`}
                title={`${state.state}: ${casesPerLakh.toFixed(0)} cases per 100K`}
              >
                <div className="font-semibold text-sm truncate">{state.state}</div>
                <div className="text-xs opacity-90">{casesPerLakh.toFixed(0)}/100K</div>
              </div>
            );
          })}
        </div>
        <div className="flex items-center justify-center space-x-6 mt-4 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded"></div>
            <span>Low (&lt;4K)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-yellow-500 rounded"></div>
            <span>Moderate (4K-6K)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-orange-500 rounded"></div>
            <span>High (6K-8K)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded"></div>
            <span>Very High (&gt;8K per 100K)</span>
          </div>
        </div>
      </div>

      {/* State Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredStates.map((state) => (
          <StateCard key={state.state} state={state} />
        ))}
      </div>

      {/* Results Info */}
      {searchTerm && (
        <div className="text-center text-gray-600">
          Showing {filteredStates.length} of {stateData.length} states/UTs
          {searchTerm && ` matching "${searchTerm}"`}
        </div>
      )}
    </div>
  );
};

export default StateAnalysis;