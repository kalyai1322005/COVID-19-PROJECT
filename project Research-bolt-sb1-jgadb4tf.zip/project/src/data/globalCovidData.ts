// Global COVID-19 Data (2020-2022) - Multiple Countries
export const globalDailyData = {
  india: [
    { date: '2020-03-15', cases: 114, deaths: 2, recovered: 13, active: 99 },
    { date: '2020-06-15', cases: 343091, deaths: 9900, recovered: 180013, active: 153178 },
    { date: '2020-09-15', cases: 4846427, deaths: 79722, recovered: 3788758, active: 977947 },
    { date: '2020-12-15', cases: 9884100, deaths: 143355, recovered: 9378434, active: 362311 },
    { date: '2021-03-15', cases: 11359048, deaths: 158725, recovered: 11082234, active: 118089 },
    { date: '2021-06-15', cases: 29633105, deaths: 377033, recovered: 28651496, active: 604576 },
    { date: '2021-09-15', cases: 33284119, deaths: 442767, recovered: 32671607, active: 169745 },
    { date: '2021-12-15', cases: 34738474, deaths: 477158, recovered: 34244394, active: 16922 },
    { date: '2022-03-15', cases: 43019546, deaths: 517443, recovered: 42471334, active: 30769 },
    { date: '2022-06-15', cases: 43226123, deaths: 525709, recovered: 42690121, active: 10293 },
    { date: '2022-09-15', cases: 44684104, deaths: 528253, recovered: 44149856, active: 5995 },
    { date: '2022-12-15', cases: 44698432, deaths: 530802, recovered: 44161700, active: 5930 }
  ],
  usa: [
    { date: '2020-03-15', cases: 3499, deaths: 68, recovered: 178, active: 3253 },
    { date: '2020-06-15', cases: 2124000, deaths: 116127, recovered: 582879, active: 1424994 },
    { date: '2020-09-15', cases: 6675304, deaths: 197595, recovered: 4092180, active: 2385529 },
    { date: '2020-12-15', cases: 16677932, deaths: 304187, recovered: 9724439, active: 6649306 },
    { date: '2021-03-15', cases: 29609597, deaths: 538184, recovered: 22879369, active: 6192044 },
    { date: '2021-06-15', cases: 33467309, deaths: 600857, recovered: 32766711, active: 99741 },
    { date: '2021-09-15', cases: 41804764, deaths: 670608, recovered: 31676494, active: 9457662 },
    { date: '2021-12-15', cases: 50648751, deaths: 806902, recovered: 39330013, active: 10511836 },
    { date: '2022-03-15', cases: 79707583, deaths: 976901, recovered: 76319020, active: 2411662 },
    { date: '2022-06-15', cases: 86330129, deaths: 1015378, recovered: 84314751, active: 1000000 },
    { date: '2022-09-15', cases: 95134665, deaths: 1048789, recovered: 93085876, active: 1000000 },
    { date: '2022-12-15', cases: 101436829, deaths: 1104364, recovered: 99332465, active: 1000000 }
  ],
  brazil: [
    { date: '2020-03-15', cases: 234, deaths: 0, recovered: 2, active: 232 },
    { date: '2020-06-15', cases: 888271, deaths: 43959, recovered: 422386, active: 421926 },
    { date: '2020-09-15', cases: 4419083, deaths: 134106, recovered: 3897539, active: 387438 },
    { date: '2020-12-15', cases: 7040608, deaths: 181402, recovered: 6204258, active: 654948 },
    { date: '2021-03-15', cases: 11693838, deaths: 284775, recovered: 10185612, active: 1223451 },
    { date: '2021-06-15', cases: 17883750, deaths: 501825, recovered: 16274695, active: 1107230 },
    { date: '2021-09-15', cases: 21247667, deaths: 592357, recovered: 20336170, active: 319140 },
    { date: '2021-12-15', cases: 22291507, deaths: 618800, recovered: 21590717, active: 81990 },
    { date: '2022-03-15', cases: 29766317, deaths: 658612, recovered: 28907705, active: 200000 },
    { date: '2022-06-15', cases: 31677662, deaths: 669045, recovered: 30808617, active: 200000 },
    { date: '2022-09-15', cases: 34687320, deaths: 685562, recovered: 33801758, active: 200000 },
    { date: '2022-12-15', cases: 35497781, deaths: 690577, recovered: 34607204, active: 200000 }
  ],
  russia: [
    { date: '2020-03-15', cases: 63, deaths: 0, recovered: 8, active: 55 },
    { date: '2020-06-15', cases: 528267, deaths: 6948, recovered: 293375, active: 227944 },
    { date: '2020-09-15', cases: 1073849, deaths: 18853, recovered: 878249, active: 176747 },
    { date: '2020-12-15', cases: 2762668, deaths: 49151, recovered: 2196423, active: 517094 },
    { date: '2021-03-15', cases: 4360823, deaths: 91220, recovered: 3973442, active: 296161 },
    { date: '2021-06-15', cases: 5281309, deaths: 128911, recovered: 4865608, active: 286790 },
    { date: '2021-09-15', cases: 7234425, deaths: 196626, recovered: 6463334, active: 574465 },
    { date: '2021-12-15', cases: 10296734, deaths: 298219, recovered: 9226411, active: 772104 },
    { date: '2022-03-15', cases: 17840048, deaths: 368675, recovered: 17271373, active: 200000 },
    { date: '2022-06-15', cases: 18441476, deaths: 381475, recovered: 17860001, active: 200000 },
    { date: '2022-09-15', cases: 21152592, deaths: 387862, recovered: 20564730, active: 200000 },
    { date: '2022-12-15', cases: 21564240, deaths: 394846, recovered: 20969394, active: 200000 }
  ],
  uk: [
    { date: '2020-03-15', cases: 1372, deaths: 35, recovered: 18, active: 1319 },
    { date: '2020-06-15', cases: 295817, deaths: 41662, recovered: 1437, active: 252718 },
    { date: '2020-09-15', cases: 378219, deaths: 41684, recovered: 2115, active: 334420 },
    { date: '2020-12-15', cases: 1977665, deaths: 65520, recovered: 3441, active: 1908704 },
    { date: '2021-03-15', cases: 4241677, deaths: 125343, recovered: 12496, active: 4103838 },
    { date: '2021-06-15', cases: 4599447, deaths: 128027, recovered: 4445939, active: 25481 },
    { date: '2021-09-15', cases: 7420616, deaths: 135455, recovered: 7260161, active: 25000 },
    { date: '2021-12-15', cases: 11007768, deaths: 146853, recovered: 10835915, active: 25000 },
    { date: '2022-03-15', cases: 20089551, deaths: 164138, recovered: 19900413, active: 25000 },
    { date: '2022-06-15', cases: 22465295, deaths: 179756, recovered: 22260539, active: 25000 },
    { date: '2022-09-15', cases: 23460787, deaths: 188692, recovered: 23247095, active: 25000 },
    { date: '2022-12-15', cases: 24265543, deaths: 194725, recovered: 24045818, active: 25000 }
  ],
  china: [
    { date: '2020-03-15', cases: 81048, deaths: 3204, recovered: 67749, active: 10095 },
    { date: '2020-06-15', cases: 83293, deaths: 4634, recovered: 78379, active: 280 },
    { date: '2020-09-15', cases: 85314, deaths: 4634, recovered: 80670, active: 10 },
    { date: '2020-12-15', cases: 86955, deaths: 4634, recovered: 82311, active: 10 },
    { date: '2021-03-15', cases: 90023, deaths: 4636, recovered: 85377, active: 10 },
    { date: '2021-06-15', cases: 91690, deaths: 4636, recovered: 87044, active: 10 },
    { date: '2021-09-15', cases: 95533, deaths: 4636, recovered: 90887, active: 10 },
    { date: '2021-12-15', cases: 99317, deaths: 4636, recovered: 94671, active: 10 },
    { date: '2022-03-15', cases: 115466, deaths: 4638, recovered: 110818, active: 10 },
    { date: '2022-06-15', cases: 225019, deaths: 5226, recovered: 219783, active: 10 },
    { date: '2022-09-15', cases: 250563, deaths: 5226, recovered: 245327, active: 10 },
    { date: '2022-12-15', cases: 389306, deaths: 5235, recovered: 384061, active: 10 }
  ],
  germany: [
    { date: '2020-03-15', cases: 4838, deaths: 12, recovered: 46, active: 4780 },
    { date: '2020-06-15', cases: 188534, deaths: 8882, recovered: 172600, active: 7052 },
    { date: '2020-09-15', cases: 267056, deaths: 9341, recovered: 238700, active: 19015 },
    { date: '2020-12-15', cases: 1379238, deaths: 23427, recovered: 1028700, active: 327111 },
    { date: '2021-03-15', cases: 2690523, deaths: 75440, recovered: 2456200, active: 158883 },
    { date: '2021-06-15', cases: 3721716, deaths: 90978, recovered: 3618600, active: 12138 },
    { date: '2021-09-15', cases: 4178841, deaths: 93770, recovered: 4070000, active: 15071 },
    { date: '2021-12-15', cases: 6719013, deaths: 108352, recovered: 6580000, active: 30661 },
    { date: '2022-03-15', cases: 19580652, deaths: 127842, recovered: 19400000, active: 52810 },
    { date: '2022-06-15', cases: 27404172, deaths: 140844, recovered: 27200000, active: 63328 },
    { date: '2022-09-15', cases: 32666778, deaths: 148781, recovered: 32500000, active: 17997 },
    { date: '2022-12-15', cases: 37434986, deaths: 161346, recovered: 37250000, active: 23640 }
  ],
  france: [
    { date: '2020-03-15', cases: 5423, deaths: 127, recovered: 12, active: 5284 },
    { date: '2020-06-15', cases: 195633, deaths: 29663, recovered: 71506, active: 94464 },
    { date: '2020-09-15', cases: 415481, deaths: 31095, recovered: 89986, active: 294400 },
    { date: '2020-12-15', cases: 2448777, deaths: 60229, recovered: 186365, active: 2202183 },
    { date: '2021-03-15', cases: 4186352, deaths: 91170, recovered: 306455, active: 3788727 },
    { date: '2021-06-15', cases: 5736777, deaths: 110563, recovered: 5598914, active: 27300 },
    { date: '2021-09-15', cases: 6971493, deaths: 116463, recovered: 6830030, active: 25000 },
    { date: '2021-12-15', cases: 8755516, deaths: 119453, recovered: 8611063, active: 25000 },
    { date: '2022-03-15', cases: 24263587, deaths: 142170, recovered: 24096417, active: 25000 },
    { date: '2022-06-15', cases: 29754732, deaths: 149718, recovered: 29580014, active: 25000 },
    { date: '2022-09-15', cases: 34299686, deaths: 167985, recovered: 34106701, active: 25000 },
    { date: '2022-12-15', cases: 38997490, deaths: 174570, recovered: 38797920, active: 25000 }
  ]
};

export const countryInfo = {
  india: { name: 'India', population: 1380004385, continent: 'Asia', capital: 'New Delhi' },
  usa: { name: 'United States', population: 331002651, continent: 'North America', capital: 'Washington D.C.' },
  brazil: { name: 'Brazil', population: 212559417, continent: 'South America', capital: 'Brasília' },
  russia: { name: 'Russia', population: 145934462, continent: 'Europe/Asia', capital: 'Moscow' },
  uk: { name: 'United Kingdom', population: 67886011, continent: 'Europe', capital: 'London' },
  china: { name: 'China', population: 1439323776, continent: 'Asia', capital: 'Beijing' },
  germany: { name: 'Germany', population: 83783942, continent: 'Europe', capital: 'Berlin' },
  france: { name: 'France', population: 65273511, continent: 'Europe', capital: 'Paris' }
};

export const globalVaccinationData = {
  india: [
    { date: '2021-01-16', firstDose: 191181, secondDose: 0, booster: 0 },
    { date: '2021-06-16', firstDose: 251115724, secondDose: 65779107, booster: 0 },
    { date: '2021-12-16', firstDose: 918371234, secondDose: 778906743, booster: 4823012 },
    { date: '2022-06-16', firstDose: 993456789, secondDose: 970456789, booster: 182345678 },
    { date: '2022-12-16', firstDose: 999890123, secondDose: 998567890, booster: 242345678 }
  ],
  usa: [
    { date: '2021-01-16', firstDose: 12279180, secondDose: 1008025, booster: 0 },
    { date: '2021-06-16', firstDose: 177135000, secondDose: 150235000, booster: 0 },
    { date: '2021-12-16', firstDose: 240000000, secondDose: 203000000, booster: 58000000 },
    { date: '2022-06-16', firstDose: 258000000, secondDose: 220000000, booster: 108000000 },
    { date: '2022-12-16', firstDose: 270000000, secondDose: 230000000, booster: 120000000 }
  ],
  brazil: [
    { date: '2021-01-16', firstDose: 214749, secondDose: 0, booster: 0 },
    { date: '2021-06-16', firstDose: 65000000, secondDose: 23000000, booster: 0 },
    { date: '2021-12-16', firstDose: 160000000, secondDose: 140000000, booster: 15000000 },
    { date: '2022-06-16', firstDose: 180000000, secondDose: 165000000, booster: 95000000 },
    { date: '2022-12-16', firstDose: 185000000, secondDose: 175000000, booster: 110000000 }
  ],
  russia: [
    { date: '2021-01-16', firstDose: 1500000, secondDose: 0, booster: 0 },
    { date: '2021-06-16', firstDose: 18000000, secondDose: 12000000, booster: 0 },
    { date: '2021-12-16', firstDose: 75000000, secondDose: 68000000, booster: 5000000 },
    { date: '2022-06-16', firstDose: 82000000, secondDose: 76000000, booster: 15000000 },
    { date: '2022-12-16', firstDose: 85000000, secondDose: 80000000, booster: 20000000 }
  ],
  uk: [
    { date: '2021-01-16', firstDose: 4266577, secondDose: 449736, booster: 0 },
    { date: '2021-06-16', firstDose: 42000000, secondDose: 30000000, booster: 0 },
    { date: '2021-12-16', firstDose: 50000000, secondDose: 46000000, booster: 25000000 },
    { date: '2022-06-16', firstDose: 53000000, secondDose: 49000000, booster: 39000000 },
    { date: '2022-12-16', firstDose: 54000000, secondDose: 50000000, booster: 40000000 }
  ],
  china: [
    { date: '2021-01-16', firstDose: 15000000, secondDose: 0, booster: 0 },
    { date: '2021-06-16', firstDose: 900000000, secondDose: 350000000, booster: 0 },
    { date: '2021-12-16', firstDose: 1220000000, secondDose: 1180000000, booster: 50000000 },
    { date: '2022-06-16', firstDose: 1280000000, secondDose: 1240000000, booster: 780000000 },
    { date: '2022-12-16', firstDose: 1300000000, secondDose: 1270000000, booster: 820000000 }
  ],
  germany: [
    { date: '2021-01-16', firstDose: 842455, secondDose: 24738, booster: 0 },
    { date: '2021-06-16', firstDose: 35000000, secondDose: 18000000, booster: 0 },
    { date: '2021-12-16', firstDose: 60000000, secondDose: 57000000, booster: 28000000 },
    { date: '2022-06-16', firstDose: 64000000, secondDose: 62000000, booster: 50000000 },
    { date: '2022-12-16', firstDose: 65000000, secondDose: 63000000, booster: 52000000 }
  ],
  france: [
    { date: '2021-01-16', firstDose: 516000, secondDose: 0, booster: 0 },
    { date: '2021-06-16', firstDose: 30000000, secondDose: 15000000, booster: 0 },
    { date: '2021-12-16', firstDose: 52000000, secondDose: 50000000, booster: 25000000 },
    { date: '2022-06-16', firstDose: 54000000, secondDose: 53000000, booster: 40000000 },
    { date: '2022-12-16', firstDose: 55000000, secondDose: 54000000, booster: 42000000 }
  ]
};

export const globalTimelineEvents = [
  {
    date: '2019-12-31',
    title: 'WHO Alerted to Pneumonia Cases',
    description: 'WHO China Country Office informed of cases of pneumonia of unknown etiology in Wuhan.',
    type: 'milestone',
    countries: ['china']
  },
  {
    date: '2020-01-11',
    title: 'First COVID-19 Death',
    description: 'China reports first death from COVID-19 in Wuhan.',
    type: 'milestone',
    countries: ['china']
  },
  {
    date: '2020-01-21',
    title: 'First US Case',
    description: 'First confirmed case of COVID-19 reported in the United States.',
    type: 'milestone',
    countries: ['usa']
  },
  {
    date: '2020-01-30',
    title: 'First India Case',
    description: 'First confirmed case reported in Kerala, India - student from Wuhan.',
    type: 'milestone',
    countries: ['india']
  },
  {
    date: '2020-02-26',
    title: 'First Brazil Case',
    description: 'Brazil confirms first case of COVID-19 in São Paulo.',
    type: 'milestone',
    countries: ['brazil']
  },
  {
    date: '2020-03-11',
    title: 'WHO Declares Pandemic',
    description: 'World Health Organization declares COVID-19 a global pandemic.',
    type: 'milestone',
    countries: ['global']
  },
  {
    date: '2020-03-24',
    title: 'India National Lockdown',
    description: 'India announces 21-day nationwide lockdown affecting 1.3 billion people.',
    type: 'policy',
    countries: ['india']
  },
  {
    date: '2020-03-26',
    title: 'US Becomes Global Epicenter',
    description: 'United States surpasses China and Italy in confirmed cases.',
    type: 'milestone',
    countries: ['usa']
  },
  {
    date: '2020-04-02',
    title: 'Global Cases Exceed 1 Million',
    description: 'Worldwide confirmed cases surpass 1 million mark.',
    type: 'milestone',
    countries: ['global']
  },
  {
    date: '2020-12-08',
    title: 'UK First Vaccination',
    description: 'UK becomes first country to begin COVID-19 vaccination program.',
    type: 'milestone',
    countries: ['uk']
  },
  {
    date: '2021-01-16',
    title: 'India Vaccination Drive',
    description: 'India launches world\'s largest vaccination campaign.',
    type: 'milestone',
    countries: ['india']
  },
  {
    date: '2021-05-07',
    title: 'India Second Wave Peak',
    description: 'India reports over 414,000 cases in single day - global record.',
    type: 'wave',
    countries: ['india']
  },
  {
    date: '2021-11-26',
    title: 'Omicron Variant Identified',
    description: 'WHO designates Omicron as variant of concern.',
    type: 'milestone',
    countries: ['global']
  },
  {
    date: '2022-01-21',
    title: 'Global Omicron Wave',
    description: 'Multiple countries experience Omicron-driven surge in cases.',
    type: 'wave',
    countries: ['global']
  }
];

export const globalInsights = [
  {
    title: 'Pandemic Waves Varied by Region',
    description: 'Different countries experienced varying wave patterns - India had 3 distinct waves, while Western countries had multiple smaller surges.',
    impact: 'High',
    countries: ['global']
  },
  {
    title: 'Vaccination Rollout Disparities',
    description: 'Significant disparities in vaccination access and rollout speed between developed and developing nations.',
    impact: 'High',
    countries: ['global']
  },
  {
    title: 'Healthcare System Responses',
    description: 'Countries with robust healthcare infrastructure generally managed better outcomes despite high case numbers.',
    impact: 'High',
    countries: ['global']
  },
  {
    title: 'Economic Impact Variations',
    description: 'Economic impacts varied significantly based on lockdown policies, healthcare capacity, and government support measures.',
    impact: 'High',
    countries: ['global']
  },
  {
    title: 'Digital Health Acceleration',
    description: 'Global acceleration in telemedicine, digital health records, and contact tracing technologies.',
    impact: 'Medium',
    countries: ['global']
  },
  {
    title: 'International Cooperation',
    description: 'Pandemic highlighted both the importance and challenges of international cooperation in health emergencies.',
    impact: 'High',
    countries: ['global']
  }
];