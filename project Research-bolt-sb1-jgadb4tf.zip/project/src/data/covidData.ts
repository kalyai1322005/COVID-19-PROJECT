// COVID-19 India Data (2020-2022)
export const dailyData = [
  // 2020 Data (March - December)
  { date: '2020-03-15', cases: 114, deaths: 2, recovered: 13, active: 99 },
  { date: '2020-04-15', cases: 12380, deaths: 414, recovered: 1489, active: 10477 },
  { date: '2020-05-15', cases: 81970, deaths: 2649, recovered: 27920, active: 51401 },
  { date: '2020-06-15', cases: 343091, deaths: 9900, recovered: 180013, active: 153178 },
  { date: '2020-07-15', cases: 936181, deaths: 24309, recovered: 590192, active: 321680 },
  { date: '2020-08-15', cases: 2461190, deaths: 48040, recovered: 1712947, active: 700203 },
  { date: '2020-09-15', cases: 4846427, deaths: 79722, recovered: 3788758, active: 977947 },
  { date: '2020-10-15', cases: 7307097, deaths: 111266, recovered: 6149535, active: 1046296 },
  { date: '2020-11-15', cases: 8683916, deaths: 128121, recovered: 8013292, active: 542503 },
  { date: '2020-12-15', cases: 9884100, deaths: 143355, recovered: 9378434, active: 362311 },
  
  // 2021 Data (Full Year)
  { date: '2021-01-15', cases: 10581823, deaths: 152718, recovered: 10207094, active: 222011 },
  { date: '2021-02-15', cases: 10925710, deaths: 156212, recovered: 10613998, active: 155500 },
  { date: '2021-03-15', cases: 11359048, deaths: 158725, recovered: 11082234, active: 118089 },
  { date: '2021-04-15', cases: 14291917, deaths: 174308, recovered: 12151555, active: 1966054 },
  { date: '2021-05-15', cases: 24372907, deaths: 266207, recovered: 20109823, active: 3996877 },
  { date: '2021-06-15', cases: 29633105, deaths: 377033, recovered: 28651496, active: 604576 },
  { date: '2021-07-15', cases: 31371901, deaths: 420551, recovered: 30543138, active: 408212 },
  { date: '2021-08-15', cases: 32332424, deaths: 433619, recovered: 31664730, active: 234075 },
  { date: '2021-09-15', cases: 33284119, deaths: 442767, recovered: 32671607, active: 169745 },
  { date: '2021-10-15', cases: 34037237, deaths: 452290, recovered: 33576990, active: 107957 },
  { date: '2021-11-15', cases: 34510696, deaths: 464623, recovered: 34019749, active: 26324 },
  { date: '2021-12-15', cases: 34738474, deaths: 477158, recovered: 34244394, active: 16922 },
  
  // 2022 Data (Full Year)
  { date: '2022-01-15', cases: 38585000, deaths: 484213, recovered: 37962234, active: 138553 },
  { date: '2022-02-15', cases: 42915915, deaths: 514031, recovered: 42329594, active: 72290 },
  { date: '2022-03-15', cases: 43019546, deaths: 517443, recovered: 42471334, active: 30769 },
  { date: '2022-04-15', cases: 43084304, deaths: 522006, recovered: 42541013, active: 21285 },
  { date: '2022-05-15', cases: 43154073, deaths: 524747, recovered: 42612563, active: 16763 },
  { date: '2022-06-15', cases: 43226123, deaths: 525709, recovered: 42690121, active: 10293 },
  { date: '2022-07-15', cases: 43826564, deaths: 526689, recovered: 43295943, active: 3932 },
  { date: '2022-08-15', cases: 44314702, deaths: 527020, recovered: 43783724, active: 3958 },
  { date: '2022-09-15', cases: 44684104, deaths: 528253, recovered: 44149856, active: 5995 },
  { date: '2022-10-15', cases: 44687173, deaths: 530712, recovered: 44150491, active: 5970 },
  { date: '2022-11-15', cases: 44690738, deaths: 530779, recovered: 44154029, active: 5930 },
  { date: '2022-12-15', cases: 44698432, deaths: 530802, recovered: 44161700, active: 5930 }
];

export const stateData = [
  { state: 'Maharashtra', cases: 8130510, deaths: 148452, recovered: 7968234, population: 112374333 },
  { state: 'Kerala', cases: 6771612, deaths: 70985, recovered: 6699537, population: 33406061 },
  { state: 'Karnataka', cases: 4009039, deaths: 40274, recovered: 3968045, population: 61095297 },
  { state: 'Tamil Nadu', cases: 3559125, deaths: 38048, recovered: 3520363, population: 72147030 },
  { state: 'Andhra Pradesh', cases: 2344934, deaths: 14733, recovered: 2329829, population: 49577103 },
  { state: 'Uttar Pradesh', cases: 1714475, deaths: 23647, recovered: 1690567, population: 199812341 },
  { state: 'West Bengal', cases: 2078033, deaths: 21295, recovered: 2056378, population: 91276115 },
  { state: 'Delhi', cases: 2017231, deaths: 26665, recovered: 1990171, population: 32941309 },
  { state: 'Odisha', cases: 1336983, deaths: 9221, recovered: 1327550, population: 42155045 },
  { state: 'Rajasthan', cases: 1278776, deaths: 9643, recovered: 1268936, population: 68548437 },
  { state: 'Chhattisgarh', cases: 1186369, deaths: 14292, recovered: 1171966, population: 25545198 },
  { state: 'Gujarat', cases: 1278484, deaths: 11148, recovered: 1267199, population: 60439692 },
  { state: 'Haryana', cases: 1077708, deaths: 10775, recovered: 1066825, population: 25351462 },
  { state: 'Madhya Pradesh', cases: 1064690, deaths: 10835, recovered: 1053755, population: 72626809 },
  { state: 'Punjab', cases: 799984, deaths: 18020, recovered: 781734, population: 27743338 },
];

export const vaccinationData = [
  { date: '2021-01-16', firstDose: 191181, secondDose: 0, booster: 0 },
  { date: '2021-02-16', firstDose: 8574079, secondDose: 32115, booster: 0 },
  { date: '2021-03-16', firstDose: 33010472, secondDose: 1649673, booster: 0 },
  { date: '2021-04-16', firstDose: 103926085, secondDose: 12073625, booster: 0 },
  { date: '2021-05-16', firstDose: 184411018, secondDose: 43950943, booster: 0 },
  { date: '2021-06-16', firstDose: 251115724, secondDose: 65779107, booster: 0 },
  { date: '2021-07-16', firstDose: 381963734, secondDose: 117799204, booster: 0 },
  { date: '2021-08-16', firstDose: 506587301, secondDose: 178877087, booster: 0 },
  { date: '2021-09-16', firstDose: 620776914, secondDose: 282338166, booster: 0 },
  { date: '2021-10-16', firstDose: 749574142, secondDose: 458142892, booster: 0 },
  { date: '2021-11-16', firstDose: 847468704, secondDose: 637071789, booster: 0 },
  { date: '2021-12-16', firstDose: 918371234, secondDose: 778906743, booster: 4823012 },
  { date: '2022-01-16', firstDose: 947834512, secondDose: 841897234, booster: 62789341 },
  { date: '2022-02-16', firstDose: 965672134, secondDose: 890234567, booster: 98765432 },
  { date: '2022-03-16', firstDose: 978234567, secondDose: 923456789, booster: 127890123 },
  { date: '2022-04-16', firstDose: 985678901, secondDose: 945678901, booster: 145678901 },
  { date: '2022-05-16', firstDose: 990123456, secondDose: 960123456, booster: 165432109 },
  { date: '2022-06-16', firstDose: 993456789, secondDose: 970456789, booster: 182345678 },
  { date: '2022-07-16', firstDose: 995789012, secondDose: 978901234, booster: 195678901 },
  { date: '2022-08-16', firstDose: 997123456, secondDose: 985234567, booster: 207890123 },
  { date: '2022-09-16', firstDose: 998456789, secondDose: 990567890, booster: 218901234 },
  { date: '2022-10-16', firstDose: 999123456, secondDose: 994890123, booster: 228012345 },
  { date: '2022-11-16', firstDose: 999567890, secondDose: 997234567, booster: 235678901 },
  { date: '2022-12-16', firstDose: 999890123, secondDose: 998567890, booster: 242345678 },
];

export const timelineEvents = [
  {
    date: '2020-01-30',
    title: 'First COVID-19 Case in India',
    description: 'First confirmed case reported in Kerala - a student who returned from Wuhan, China.',
    type: 'milestone'
  },
  {
    date: '2020-03-24',
    title: 'National Lockdown Announced',
    description: 'PM Modi announced a 21-day nationwide lockdown affecting 1.3 billion people.',
    type: 'policy'
  },
  {
    date: '2020-04-14',
    title: 'Lockdown Extended',
    description: 'Lockdown extended till May 3, 2020, with conditional relaxations in some areas.',
    type: 'policy'
  },
  {
    date: '2020-06-01',
    title: 'Unlock 1.0 Begins',
    description: 'Phased reopening begins with Unlock 1.0, allowing certain activities outside containment zones.',
    type: 'policy'
  },
  {
    date: '2020-09-16',
    title: 'Peak Daily Cases (First Wave)',
    description: 'India recorded its highest single-day spike of 97,894 cases during the first wave.',
    type: 'milestone'
  },
  {
    date: '2021-01-16',
    title: 'Vaccination Drive Begins',
    description: 'India launched one of the world\'s largest vaccination campaigns.',
    type: 'milestone'
  },
  {
    date: '2021-04-01',
    title: 'Second Wave Begins',
    description: 'India enters the devastating second wave with exponential case growth.',
    type: 'wave'
  },
  {
    date: '2021-05-07',
    title: 'Peak Daily Cases (Second Wave)',
    description: 'India reported over 414,000 cases in a single day, the highest globally.',
    type: 'milestone'
  },
  {
    date: '2021-05-01',
    title: 'Oxygen Crisis',
    description: 'Severe oxygen shortage across hospitals, international aid begins.',
    type: 'crisis'
  },
  {
    date: '2021-10-21',
    title: 'One Billion Vaccination Milestone',
    description: 'India achieves the milestone of administering 1 billion vaccine doses.',
    type: 'milestone'
  },
  {
    date: '2022-01-15',
    title: 'Omicron Wave (Third Wave)',
    description: 'Third wave driven by Omicron variant, milder symptoms but high transmissibility.',
    type: 'wave'
  },
  {
    date: '2022-02-10',
    title: 'Omicron Peak',
    description: 'Third wave peaks with over 347,000 daily cases but lower hospitalization rates.',
    type: 'milestone'
  }
];

export const keyInsights = [
  {
    title: 'Three Distinct Waves',
    description: 'India experienced three major waves: First wave (Sept 2020), Second wave (Apr-May 2021), and Third wave (Jan-Feb 2022).',
    impact: 'High'
  },
  {
    title: 'Vaccination Success',
    description: 'India administered over 2.2 billion vaccine doses, achieving significant population coverage.',
    impact: 'High'
  },
  {
    title: 'Regional Variations',
    description: 'Maharashtra, Kerala, and Karnataka were the most affected states by total cases.',
    impact: 'Medium'
  },
  {
    title: 'Healthcare System Strain',
    description: 'The second wave severely strained healthcare infrastructure, leading to oxygen shortages.',
    impact: 'High'
  },
  {
    title: 'Economic Impact',
    description: 'Lockdowns and restrictions significantly impacted the economy, with GDP contracting in 2020.',
    impact: 'High'
  },
  {
    title: 'Digital Health Innovation',
    description: 'Rapid adoption of telemedicine and digital health solutions during the pandemic.',
    impact: 'Medium'
  }
];