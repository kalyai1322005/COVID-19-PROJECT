import React, { useState } from 'react';
import GlobalDashboard from './components/GlobalDashboard';
import GlobalDataVisualization from './components/GlobalDataVisualization';
import CountryComparison from './components/CountryComparison';
import GlobalTimeline from './components/GlobalTimeline';
import GlobalInsights from './components/GlobalInsights';
import { Activity, BarChart3, Globe, Clock, FileText, Database } from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState('global-dashboard');

  const tabs = [
    { id: 'global-dashboard', label: 'Global Dashboard', icon: Activity },
    { id: 'visualization', label: 'Data Visualization', icon: BarChart3 },
    { id: 'countries', label: 'Country Comparison', icon: Globe },
    { id: 'timeline', label: 'Global Timeline', icon: Clock },
    { id: 'insights', label: 'Global Insights', icon: FileText },
  ];

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'global-dashboard':
        return <GlobalDashboard />;
      case 'visualization':
        return <GlobalDataVisualization />;
      case 'countries':
        return <CountryComparison />;
      case 'timeline':
        return <GlobalTimeline />;
      case 'insights':
        return <GlobalInsights />;
      default:
        return <GlobalDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-lg border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <Database className="h-8 w-8 text-indigo-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Global COVID-19 Analysis</h1>
                <p className="text-sm text-gray-600">Multi-Country Comparative Analysis (2020-2022)</p>
              </div>
            </div>
            <div className="text-sm text-gray-500">
              Data Period: March 2020 - December 2022
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8 overflow-x-auto">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200 ${
                    activeTab === tab.id
                      ? 'border-indigo-500 text-indigo-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span className="whitespace-nowrap">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderActiveComponent()}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-sm text-gray-300">
              Global COVID-19 Data Analysis Project | Multi-Country Research & Visualization
            </p>
            <p className="text-xs text-gray-400 mt-2">
              Data sources: WHO, Johns Hopkins University, National Health Ministries, Our World in Data
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;