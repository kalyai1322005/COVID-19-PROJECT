// COVID-19 India Data (2020-2022) - Simulated realistic data patterns

export interface CovidDataPoint {
  date: string;
  state: string;
  totalCases: number;
  activeCases: number;
  recovered: number;
  deaths: number;
  dailyNew: number;
  recoveryRate: number;
}

export interface StateData {
  totalCases: number;
  activeCases: number;
  recovered: number;
  deaths: number;
  casesChange: number;
  activeChange: number;
  recoveredChange: number;
  deathsChange: number;
}

export interface TimeSeriesData {
  monthly: Array<{ label: string; value: number }>;
  recoveryRate: Array<{ label: string; value: number }>;
  dailyCases: Array<{ label: string; value: number }>;
}

// Simulated COVID-19 data for India
export const covidData = {
  stateDistribution: [
    { label: 'Maharashtra', value: 7850000, color: 'bg-red-500' },
    { label: 'Kerala', value: 6680000, color: 'bg-orange-500' },
    { label: 'Karnataka', value: 3980000, color: 'bg-yellow-500' },
    { label: 'Tamil Nadu', value: 3540000, color: 'bg-green-500' },
    { label: 'Andhra Pradesh', value: 2340000, color: 'bg-blue-500' },
    { label: 'Uttar Pradesh', value: 1710000, color: 'bg-indigo-500' },
    { label: 'Delhi', value: 1440000, color: 'bg-purple-500' },
    { label: 'West Bengal', value: 1580000, color: 'bg-pink-500' },
    { label: 'Gujarat', value: 1260000, color: 'bg-gray-500' },
    { label: 'Rajasthan', value: 1020000, color: 'bg-red-400' },
  ],

  nationalTrends: {
    2020: { cases: 10700000, deaths: 154000, recovered: 10400000 },
    2021: { cases: 28500000, deaths: 350000, recovered: 27900000 },
    2022: { cases: 5500000, deaths: 28000, recovered: 5450000 }
  }
};

export const getStateData = (state: string, year: string): StateData => {
  const baseData = {
    'All India': {
      2020: { totalCases: 10700000, activeCases: 146000, recovered: 10400000, deaths: 154000 },
      2021: { totalCases: 28500000, activeCases: 250000, recovered: 27900000, deaths: 350000 },
      2022: { totalCases: 5500000, activeCases: 22000, recovered: 5450000, deaths: 28000 }
    },
    'Maharashtra': {
      2020: { totalCases: 2050000, activeCases: 28000, recovered: 2000000, deaths: 22000 },
      2021: { totalCases: 4800000, activeCases: 45000, recovered: 4700000, deaths: 55000 },
      2022: { totalCases: 1000000, activeCases: 5000, recovered: 990000, deaths: 5000 }
    },
    'Kerala': {
      2020: { totalCases: 1680000, activeCases: 25000, recovered: 1650000, deaths: 5000 },
      2021: { totalCases: 3200000, activeCases: 50000, recovered: 3140000, deaths: 10000 },
      2022: { totalCases: 1800000, activeCases: 8000, recovered: 1790000, deaths: 2000 }
    }
  };

  const data = baseData[state as keyof typeof baseData]?.[year as keyof typeof baseData['All India']] || 
               baseData['All India'][year as keyof typeof baseData['All India']];

  return {
    ...data,
    casesChange: Math.random() > 0.5 ? Math.floor(Math.random() * 15) : -Math.floor(Math.random() * 15),
    activeChange: Math.random() > 0.5 ? Math.floor(Math.random() * 25) : -Math.floor(Math.random() * 25),
    recoveredChange: Math.floor(Math.random() * 10) + 5,
    deathsChange: Math.random() > 0.7 ? Math.floor(Math.random() * 8) : -Math.floor(Math.random() * 5)
  };
};

export const getTimeSeriesData = (state: string): TimeSeriesData => {
  const months = [
    'Jan 2020', 'Feb 2020', 'Mar 2020', 'Apr 2020', 'May 2020', 'Jun 2020',
    'Jul 2020', 'Aug 2020', 'Sep 2020', 'Oct 2020', 'Nov 2020', 'Dec 2020',
    'Jan 2021', 'Feb 2021', 'Mar 2021', 'Apr 2021', 'May 2021', 'Jun 2021',
    'Jul 2021', 'Aug 2021', 'Sep 2021', 'Oct 2021', 'Nov 2021', 'Dec 2021',
    'Jan 2022', 'Feb 2022', 'Mar 2022', 'Apr 2022', 'May 2022', 'Jun 2022'
  ];

  // Simulated monthly case patterns (realistic COVID-19 wave patterns)
  const casePattern = [
    1000, 5000, 25000, 65000, 85000, 120000, // 2020 first wave
    150000, 180000, 220000, 280000, 320000, 380000,
    450000, 520000, 680000, 850000, 950000, 780000, // 2021 second wave peak
    650000, 520000, 420000, 320000, 280000, 240000,
    350000, 450000, 280000, 180000, 120000, 80000 // 2022 omicron wave
  ];

  const recoveryPattern = months.map((_, index) => ({
    label: months[index],
    value: Math.min(95, 65 + (index * 1.2)) // Recovery rate improving over time
  }));

  const dailyCasesPattern = months.map((_, index) => ({
    label: months[index],
    value: casePattern[index] + (Math.random() - 0.5) * casePattern[index] * 0.1
  }));

  return {
    monthly: months.map((month, index) => ({
      label: month,
      value: casePattern[index]
    })),
    recoveryRate: recoveryPattern,
    dailyCases: dailyCasesPattern
  };
};