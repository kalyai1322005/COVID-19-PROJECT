import React, { useState } from 'react';
import { Database, Filter, Download, RefreshCw, AlertCircle, CheckCircle } from 'lucide-react';

const DataAnalysis: React.FC = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [analysisComplete, setAnalysisComplete] = useState(false);

  const handleRunAnalysis = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setAnalysisComplete(true);
    }, 3000);
  };

  const analysisSteps = [
    { name: 'Data Collection', status: 'completed', description: 'Gathered COVID-19 data from multiple sources including Ministry of Health' },
    { name: 'Data Cleaning', status: 'completed', description: 'Removed duplicates, handled missing values, standardized formats' },
    { name: 'Data Validation', status: 'completed', description: 'Verified data integrity and cross-referenced with official sources' },
    { name: 'Statistical Analysis', status: analysisComplete ? 'completed' : 'pending', description: 'Performed correlation analysis, trend detection, and regression modeling' },
    { name: 'Visualization', status: analysisComplete ? 'completed' : 'pending', description: 'Created interactive charts and geographic visualizations' },
  ];

  const datasetInfo = {
    source: 'Ministry of Health & Family Welfare, India',
    period: 'January 2020 - December 2022',
    records: '1,095,000+',
    states: '28 States + 8 Union Territories',
    lastUpdated: '2023-01-15',
    fileSize: '145.2 MB'
  };

  const analysisResults = [
    {
      metric: 'Peak Infection Rate',
      value: '0.034%',
      description: 'Highest daily infection rate observed in May 2021',
      insight: 'Second wave peaked significantly higher than first wave'
    },
    {
      metric: 'Average Recovery Time',
      value: '14.2 days',
      description: 'Mean time from diagnosis to recovery',
      insight: 'Recovery time decreased over the analysis period due to improved treatment'
    },
    {
      metric: 'Mortality Rate',
      value: '1.19%',
      description: 'Overall case fatality rate across the study period',
      insight: 'Lower than global average, indicating effective healthcare response'
    },
    {
      metric: 'Vaccination Correlation',
      value: '0.87',
      description: 'Correlation between vaccination rate and case reduction',
      insight: 'Strong positive correlation shows vaccine effectiveness'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Dataset Information */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center space-x-3 mb-6">
          <Database className="h-6 w-6 text-blue-600" />
          <h2 className="text-xl font-semibold text-slate-900">Dataset Information</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Object.entries(datasetInfo).map(([key, value]) => (
            <div key={key} className="bg-slate-50 rounded-lg p-4">
              <div className="text-sm font-medium text-slate-600 capitalize mb-1">
                {key.replace(/([A-Z])/g, ' $1').trim()}
              </div>
              <div className="text-lg font-semibold text-slate-900">{value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Data Processing Pipeline */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <Filter className="h-6 w-6 text-blue-600" />
            <h2 className="text-xl font-semibold text-slate-900">Data Processing Pipeline</h2>
          </div>
          <button
            onClick={handleRunAnalysis}
            disabled={isProcessing}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {isProcessing ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
            <span>{isProcessing ? 'Processing...' : 'Run Analysis'}</span>
          </button>
        </div>

        <div className="space-y-4">
          {analysisSteps.map((step, index) => (
            <div key={index} className="flex items-start space-x-4 p-4 bg-slate-50 rounded-lg">
              <div className="flex-shrink-0 mt-1">
                {step.status === 'completed' ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : isProcessing && index >= 3 ? (
                  <RefreshCw className="h-5 w-5 text-blue-500 animate-spin" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-slate-400" />
                )}
              </div>
              <div className="flex-1">
                <h3 className="font-medium text-slate-900">{step.name}</h3>
                <p className="text-sm text-slate-600 mt-1">{step.description}</p>
              </div>
              <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                step.status === 'completed' 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-slate-100 text-slate-600'
              }`}>
                {step.status === 'completed' ? 'Completed' : 'Pending'}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Analysis Results */}
      {analysisComplete && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-slate-900">Analysis Results</h2>
            <button className="flex items-center space-x-2 px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors">
              <Download className="h-4 w-4" />
              <span>Export Results</span>
            </button>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {analysisResults.map((result, index) => (
              <div key={index} className="border border-slate-200 rounded-lg p-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-slate-900">{result.metric}</h3>
                  <span className="text-2xl font-bold text-blue-600">{result.value}</span>
                </div>
                <p className="text-sm text-slate-600 mb-3">{result.description}</p>
                <div className="bg-blue-50 rounded-md p-3">
                  <p className="text-sm text-blue-800">
                    <strong>Insight:</strong> {result.insight}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Code Implementation */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h2 className="text-xl font-semibold text-slate-900 mb-6">Data Processing Code</h2>
        
        <div className="bg-slate-900 rounded-lg p-6 overflow-x-auto">
          <pre className="text-green-400 text-sm">
{`# COVID-19 Data Analysis - India (2020-2022)
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

# Data Loading and Cleaning
def load_and_clean_data():
    # Load data from multiple sources
    df = pd.read_csv('covid_india_2020_2022.csv')
    
    # Data cleaning steps
    df = df.dropna(subset=['Date', 'State', 'Confirmed'])
    df['Date'] = pd.to_datetime(df['Date'])
    df = df.sort_values(['State', 'Date'])
    
    # Calculate daily new cases
    df['Daily_New_Cases'] = df.groupby('State')['Confirmed'].diff().fillna(0)
    
    # Calculate recovery rate
    df['Recovery_Rate'] = (df['Recovered'] / df['Confirmed'] * 100).round(2)
    
    return df

# Statistical Analysis
def perform_analysis(df):
    # Time series analysis
    monthly_cases = df.groupby(df['Date'].dt.to_period('M')).sum()
    
    # State-wise analysis
    state_summary = df.groupby('State').agg({
        'Confirmed': 'max',
        'Recovered': 'max',
        'Deaths': 'max',
        'Recovery_Rate': 'mean'
    }).round(2)
    
    # Correlation analysis
    correlation_matrix = df[['Confirmed', 'Recovered', 'Deaths']].corr()
    
    return monthly_cases, state_summary, correlation_matrix

# Visualization
def create_visualizations(df):
    # Time series plot
    plt.figure(figsize=(12, 6))
    df.groupby('Date')['Daily_New_Cases'].sum().plot()
    plt.title('Daily New Cases - India (2020-2022)')
    plt.xlabel('Date')
    plt.ylabel('New Cases')
    plt.show()
    
    # State-wise distribution
    top_states = df.groupby('State')['Confirmed'].max().nlargest(10)
    plt.figure(figsize=(10, 6))
    top_states.plot(kind='bar')
    plt.title('Top 10 States by Total Cases')
    plt.xticks(rotation=45)
    plt.show()

# Main execution
if __name__ == "__main__":
    df = load_and_clean_data()
    monthly_cases, state_summary, correlation_matrix = perform_analysis(df)
    create_visualizations(df)
    
    print("Analysis completed successfully!")
    print(f"Total records processed: {len(df):,}")
    print(f"Date range: {df['Date'].min()} to {df['Date'].max()}")
`}
          </pre>
        </div>
      </div>
    </div>
  );
};

export default DataAnalysis;