import React, { useState } from 'react';
import { TrendingUp, TrendingDown, Users, Activity, Calendar, MapPin } from 'lucide-react';
import StatCard from './StatCard';
import ChartContainer from './ChartContainer';
import { covidData, getStateData, getTimeSeriesData } from '../data/covidData';

const Dashboard: React.FC = () => {
  const [selectedState, setSelectedState] = useState('All India');
  const [selectedYear, setSelectedYear] = useState('2021');

  const states = ['All India', 'Maharashtra', 'Kerala', 'Karnataka', 'Tamil Nadu', 'Andhra Pradesh', 'Uttar Pradesh', 'Delhi', 'West Bengal', 'Gujarat'];
  const years = ['2020', '2021', '2022'];

  const currentData = getStateData(selectedState, selectedYear);
  const timeSeriesData = getTimeSeriesData(selectedState);

  return (
    <div className="space-y-8">
      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-2">
            <MapPin className="h-5 w-5 text-slate-600" />
            <span className="font-medium text-slate-900">Filters:</span>
          </div>
          <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium text-slate-700">State:</label>
              <select
                value={selectedState}
                onChange={(e) => setSelectedState(e.target.value)}
                className="px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {states.map((state) => (
                  <option key={state} value={state}>{state}</option>
                ))}
              </select>
            </div>
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium text-slate-700">Year:</label>
              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value)}
                className="px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {years.map((year) => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Key Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Cases"
          value={currentData.totalCases.toLocaleString()}
          change={currentData.casesChange}
          icon={Users}
          color="blue"
        />
        <StatCard
          title="Active Cases"
          value={currentData.activeCases.toLocaleString()}
          change={currentData.activeChange}
          icon={Activity}
          color="orange"
        />
        <StatCard
          title="Recovered"
          value={currentData.recovered.toLocaleString()}
          change={currentData.recoveredChange}
          icon={TrendingUp}
          color="green"
        />
        <StatCard
          title="Deaths"
          value={currentData.deaths.toLocaleString()}
          change={currentData.deathsChange}
          icon={TrendingDown}
          color="red"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <ChartContainer
          title="Monthly Cases Trend"
          subtitle={`${selectedState} - ${selectedYear}`}
          data={timeSeriesData.monthly}
          type="line"
        />
        <ChartContainer
          title="State-wise Distribution"
          subtitle="Top 10 States by Total Cases"
          data={covidData.stateDistribution}
          type="bar"
        />
        <ChartContainer
          title="Recovery Rate Timeline"
          subtitle="Recovery percentage over time"
          data={timeSeriesData.recoveryRate}
          type="area"
        />
        <ChartContainer
          title="Daily New Cases"
          subtitle="7-day moving average"
          data={timeSeriesData.dailyCases}
          type="line"
        />
      </div>

      {/* Insights Panel */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Calendar className="h-5 w-5 text-slate-600" />
          <h3 className="text-lg font-semibold text-slate-900">Key Insights</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-blue-50 rounded-lg p-4">
            <h4 className="font-medium text-blue-900 mb-2">Peak Period</h4>
            <p className="text-sm text-blue-700">
              The highest number of daily cases was recorded in May 2021 during the second wave, 
              with over 400,000 cases per day nationally.
            </p>
          </div>
          <div className="bg-green-50 rounded-lg p-4">
            <h4 className="font-medium text-green-900 mb-2">Recovery Rate</h4>
            <p className="text-sm text-green-700">
              India maintained a recovery rate of over 95% throughout 2021-2022, 
              indicating effective treatment protocols and healthcare management.
            </p>
          </div>
          <div className="bg-purple-50 rounded-lg p-4">
            <h4 className="font-medium text-purple-900 mb-2">Vaccination Impact</h4>
            <p className="text-sm text-purple-700">
              The vaccination drive launched in January 2021 significantly reduced 
              severe cases and mortality rates in the latter half of 2021.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;