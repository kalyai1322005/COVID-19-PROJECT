import React, { useState } from 'react';
import { FileText, Download, Send, Calendar, Users, TrendingUp, BarChart3 } from 'lucide-react';

const ReportGenerator: React.FC = () => {
  const [selectedSections, setSelectedSections] = useState({
    executive: true,
    methodology: true,
    findings: true,
    visualizations: true,
    conclusions: true,
    recommendations: true
  });

  const [reportFormat, setReportFormat] = useState('pdf');

  const reportSections = [
    { id: 'executive', label: 'Executive Summary', description: 'High-level overview of key findings' },
    { id: 'methodology', label: 'Methodology', description: 'Data sources, cleaning process, and analysis methods' },
    { id: 'findings', label: 'Key Findings', description: 'Statistical results and trends analysis' },
    { id: 'visualizations', label: 'Data Visualizations', description: 'Charts, graphs, and visual representations' },
    { id: 'conclusions', label: 'Conclusions', description: 'Interpretations and implications of the data' },
    { id: 'recommendations', label: 'Recommendations', description: 'Actionable insights and future directions' }
  ];

  const keyFindings = [
    {
      title: 'Peak Impact Period',
      description: 'Second wave (April-June 2021) showed 300% higher case numbers compared to first wave',
      impact: 'High'
    },
    {
      title: 'State Variations',
      description: 'Maharashtra, Kerala, and Karnataka were most affected states accounting for 35% of total cases',
      impact: 'Medium'
    },
    {
      title: 'Recovery Patterns',
      description: 'National recovery rate improved from 85% in 2020 to 98% in 2022',
      impact: 'High'
    },
    {
      title: 'Vaccination Impact',
      description: 'States with higher vaccination rates showed 65% faster decline in active cases',
      impact: 'High'
    }
  ];

  const handleSectionToggle = (sectionId: string) => {
    setSelectedSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  return (
    <div className="space-y-8">
      {/* Report Configuration */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center space-x-3 mb-6">
          <FileText className="h-6 w-6 text-blue-600" />
          <h2 className="text-xl font-semibold text-slate-900">Report Configuration</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Section Selection */}
          <div>
            <h3 className="font-medium text-slate-900 mb-4">Select Report Sections</h3>
            <div className="space-y-3">
              {reportSections.map((section) => (
                <div key={section.id} className="flex items-start space-x-3">
                  <input
                    type="checkbox"
                    id={section.id}
                    checked={selectedSections[section.id as keyof typeof selectedSections]}
                    onChange={() => handleSectionToggle(section.id)}
                    className="mt-1 h-4 w-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                  />
                  <div className="flex-1">
                    <label htmlFor={section.id} className="font-medium text-slate-700 cursor-pointer">
                      {section.label}
                    </label>
                    <p className="text-sm text-slate-500 mt-1">{section.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Format Options */}
          <div>
            <h3 className="font-medium text-slate-900 mb-4">Export Format</h3>
            <div className="space-y-3">
              {[
                { id: 'pdf', label: 'PDF Report', description: 'Professional formatted document' },
                { id: 'slides', label: 'Presentation Slides', description: 'PowerPoint/Google Slides format' },
                { id: 'html', label: 'Web Report', description: 'Interactive HTML document' },
                { id: 'csv', label: 'Data Export', description: 'Raw data in CSV format' }
              ].map((format) => (
                <div key={format.id} className="flex items-center space-x-3">
                  <input
                    type="radio"
                    id={format.id}
                    name="format"
                    value={format.id}
                    checked={reportFormat === format.id}
                    onChange={(e) => setReportFormat(e.target.value)}
                    className="h-4 w-4 text-blue-600 border-slate-300 focus:ring-blue-500"
                  />
                  <div>
                    <label htmlFor={format.id} className="font-medium text-slate-700 cursor-pointer">
                      {format.label}
                    </label>
                    <p className="text-sm text-slate-500">{format.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Key Findings Preview */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h2 className="text-xl font-semibold text-slate-900 mb-6">Key Findings Preview</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {keyFindings.map((finding, index) => (
            <div key={index} className="border border-slate-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-slate-900">{finding.title}</h3>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  finding.impact === 'High' 
                    ? 'bg-red-100 text-red-700'
                    : 'bg-yellow-100 text-yellow-700'
                }`}>
                  {finding.impact} Impact
                </span>
              </div>
              <p className="text-sm text-slate-600">{finding.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Executive Summary Preview */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h2 className="text-xl font-semibold text-slate-900 mb-6">Executive Summary Preview</h2>
        
        <div className="prose max-w-none">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">COVID-19 Data Analysis: India (2020-2022)</h3>
          
          <div className="bg-slate-50 rounded-lg p-6 mb-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-blue-600">44.7M</div>
                <div className="text-sm text-slate-600">Total Cases</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-600">44.1M</div>
                <div className="text-sm text-slate-600">Recovered</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-orange-600">532K</div>
                <div className="text-sm text-slate-600">Deaths</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-purple-600">98.7%</div>
                <div className="text-sm text-slate-600">Recovery Rate</div>
              </div>
            </div>
          </div>

          <div className="space-y-4 text-slate-700">
            <p>
              This comprehensive analysis examines COVID-19 data across India from January 2020 to December 2022, 
              covering all 28 states and 8 union territories. The study reveals significant patterns in disease 
              transmission, recovery rates, and the effectiveness of public health interventions.
            </p>
            
            <p>
              <strong>Key Observations:</strong> India experienced two distinct waves during the analysis period, 
              with the second wave (April-June 2021) showing significantly higher case numbers but improved 
              treatment outcomes. The national vaccination drive, launched in January 2021, correlated strongly 
              with reduced mortality rates and faster recovery times.
            </p>
            
            <p>
              <strong>Geographic Variations:</strong> Urban states and those with higher population density 
              initially showed higher case numbers, but also demonstrated more effective containment strategies 
              over time. Rural areas showed delayed but prolonged transmission patterns.
            </p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
          <button className="flex items-center justify-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <Download className="h-5 w-5" />
            <span>Generate Report</span>
          </button>
          
          <button className="flex items-center justify-center space-x-2 px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors">
            <Send className="h-5 w-5" />
            <span>Share Report</span>
          </button>
          
          <button className="flex items-center justify-center space-x-2 px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors">
            <Calendar className="h-5 w-5" />
            <span>Schedule Delivery</span>
          </button>
        </div>
        
        <div className="mt-4 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-800">
            <strong>GitHub Repository:</strong> The complete source code, datasets, and analysis scripts 
            are available at <code className="bg-blue-100 px-2 py-1 rounded">github.com/your-username/covid-india-analysis</code>
          </p>
        </div>
      </div>
    </div>
  );
};

export default ReportGenerator;