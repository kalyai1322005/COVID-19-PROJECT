import React from 'react';
import { MoreHorizontal } from 'lucide-react';

interface ChartData {
  label: string;
  value: number;
  color?: string;
}

interface ChartContainerProps {
  title: string;
  subtitle: string;
  data: ChartData[];
  type: 'line' | 'bar' | 'area';
}

const ChartContainer: React.FC<ChartContainerProps> = ({ title, subtitle, data, type }) => {
  const maxValue = Math.max(...data.map(d => d.value));
  
  const renderChart = () => {
    switch (type) {
      case 'bar':
        return (
          <div className="space-y-3">
            {data.slice(0, 8).map((item, index) => (
              <div key={index} className="flex items-center space-x-3">
                <div className="w-20 text-sm text-slate-600 truncate">{item.label}</div>
                <div className="flex-1 bg-slate-100 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${item.color || 'bg-blue-500'}`}
                    style={{ width: `${(item.value / maxValue) * 100}%` }}
                  />
                </div>
                <div className="w-16 text-sm font-medium text-slate-900 text-right">
                  {item.value.toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        );
      
      case 'line':
      case 'area':
        return (
          <div className="relative h-48">
            <svg className="w-full h-full">
              <defs>
                <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
                </linearGradient>
              </defs>
              
              {/* Grid lines */}
              {[0, 0.25, 0.5, 0.75, 1].map((y, i) => (
                <line
                  key={i}
                  x1="0"
                  y1={`${y * 100}%`}
                  x2="100%"
                  y2={`${y * 100}%`}
                  stroke="#e2e8f0"
                  strokeWidth="1"
                />
              ))}
              
              {/* Chart line */}
              <polyline
                fill={type === 'area' ? 'url(#areaGradient)' : 'none'}
                stroke="#3b82f6"
                strokeWidth="2"
                points={data.map((item, index) => {
                  const x = (index / (data.length - 1)) * 100;
                  const y = 100 - (item.value / maxValue) * 100;
                  return `${x},${y}`;
                }).join(' ')}
              />
              
              {/* Data points */}
              {data.map((item, index) => {
                const x = (index / (data.length - 1)) * 100;
                const y = 100 - (item.value / maxValue) * 100;
                return (
                  <circle
                    key={index}
                    cx={`${x}%`}
                    cy={`${y}%`}
                    r="3"
                    fill="#3b82f6"
                    stroke="white"
                    strokeWidth="2"
                  />
                );
              })}
            </svg>
            
            {/* X-axis labels */}
            <div className="absolute -bottom-6 left-0 right-0 flex justify-between text-xs text-slate-500">
              {data.map((item, index) => (
                <span key={index} className={index % 2 === 0 ? '' : 'hidden sm:inline'}>
                  {item.label}
                </span>
              ))}
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-slate-900">{title}</h3>
          <p className="text-sm text-slate-600">{subtitle}</p>
        </div>
        <button className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors">
          <MoreHorizontal className="h-5 w-5" />
        </button>
      </div>
      
      {renderChart()}
    </div>
  );
};

export default ChartContainer;